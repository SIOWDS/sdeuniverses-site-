# 第24卷《SDE交互医学》第二审记录

审校日期：2026年10月30日。审校性质：内部 AI 协作编校中的医学事实、证据身份与临床表述审查。此记录不构成外部医学同行评审，也不表示本书理论或配套智能体已经获得临床验证。

## 审校结论

建议合入八处精确修订，再由总编辑完成阅读版、学习稿、智能体的语义同步与终校。本轮重点核对范围内，未发现需要另行撤回作者理论、删去整章或暂停排版的新增重大医学安全问题。现稿已经较清楚地区分作者解释框架、待检验假说、构造案例、指南建议与已有临床研究，修订应保存这些区别。

主补丁文件 `medical_review.json` 含 MED-001 至 MED-007；追加文件 `medical_review_addendum.json` 仅含 MED-008，避免对已经应用的七条重复操作。八条 old 均在审校输入原稿中精确出现一次，均附理由和对应来源。未直接改动主稿。

## 实际审读范围

对全60章标题及1,514个正文段落进行风险语句、治疗数值和证据提示语的机器扫描；通读导论、重点临床章及逐章抽取的证据段落，补充整章复核第12、15—17、22、55、57—58、60章。重点包括高血压、高血糖、血脂异常、运动、呼吸练习、减停药、缓解、能力更新与年轻化表述。与负责全本连续通读的一审保持交叉反馈。

本审不声称独立逐字复核全部正文，也不把搜索取得的一手相关段落称为整篇外部文献全文重审。部分原刊直接打开受限时，记录了实际可核对范围。中国2025年基层高血压指南的原刊身份已确认，但本次直接网页正文抓取受限；未据此虚构全文验证记录。

## 八处精确修订

| 编号 | 位置 | 修订内容与理由 |
|---|---|---|
| MED-001 | 第25章 | 补足美国2025年第一阶段高血压分类依规范测量平均值、收缩压与舒张压分属不同范围取较高类别的条件；避免与中国1级高血压混名。 |
| MED-002 | 第44章 | 将 HPS 的19.8%对25.2%、绝对5.4个百分点明确为预定五年治疗期间首次重大血管事件，补足时间和结局定义。 |
| MED-003 | 第56章 | 保留缓解判定的停用降糖药至少三个月条件，补上生活方式干预开始至少六个月的评价时点及 HbA1c 适用性限制。 |
| MED-004 | 第59章 | 保留2015年 TRIPOD 的历史贡献，补充2024年 TRIPOD+AI 已取代旧报告清单、同时覆盖回归和机器学习模型。 |
| MED-005 | 参考文献 | 为 WHO 康复事实清单补全机构、文献类型及2024年4月22日。 |
| MED-006 | 参考文献 | 为 WHO 康复问答补全机构、文献类型及2024年9月30日。 |
| MED-007 | 参考文献 | 新增2024年 TRIPOD+AI 正式文献，与第59章新增正文对应。 |
| MED-008 | 第42章 | 按 WHO 2023正式指南区分饱和脂肪与反式脂肪的推荐替代物，不再用同一句把两类推荐完全合并。 |

## 重要核验及保留判断

**WHO 康复年份可以保留。** 官方事实清单确为2024年4月22日，问答确为2024年9月30日。正文中的2024年与文献日期一致，不能因本次检索发生于2026年就统一覆盖为2026年。其内容支持现有康复已重视功能、环境与参与，不支持 SDE 的额外临床疗效。

**其他2026年引用也有实际版本依据。** NICE NG136 于2026年2月26日更新；NHS 压力呼吸页面于2026年6月12日复核，他汀页面于2026年5月5日复核。2026年美国血脂异常指南和 ADA 2026 各章确有对应正式资料。已核年份应按文献版本保留，检索日期另记。

**高血压与血脂结局的适用人群应保留。** ESC 2024 的治疗目标有耐受性及特定老年、脆弱状态等限制。OPTiMISE 延长随访针对经过选择、由医生实施撤减一种降压药的高龄人群，未检出住院或死亡增加不能改写成对所有人证明停药等效。HPS 的药物分配、研究人群、五年时段及首次重大血管事件应同时保留，绝对差不能当作个人保证。

**低血糖、糖尿病危象与药物任务不能被过程语言覆盖。** ADA 2026 的低血糖分级与现稿相符；严重低血糖的判断不依赖某一读数。正文保留不能进食者不强行喂食、需要时联系当地急救、DKA 可在并非极高血糖下出现等边界。特定药物的心肾结局任务可能不只取决于当前 HbA1c，CGM 也不能取消备用血糖检测条件。此处未新增个人处方或剂量。

**运动与年轻化保留为有边界的论述。** ME/CFS 指南反对固定递增运动方案的内容仅用于相应疾病，不扩展为所有慢性病禁止活动。书稿把低负荷、疲劳、出汗和单次运动后读数与长期临床结局区分开；没有把燃脂等同于清除 LDL 或斑块。“年轻化”限定为特定任务与条件下的能力更新研究命题，不承诺生物年龄逆转、延寿或普遍治愈。

**缓解不是治愈，也不能用自行停药换取名称。** 2021年国际共识的时间条件需补足；DiRECT 五年结果保留原试验、延长期选择与实际随访分母的区别。当前章节已有至少年度复查与并发症随访论述，无需为制造改动重复增加。

## 配套学习稿与智能体的同步要求

八处修订涉及的数值、年份和证据身份应沿同一母稿进入配套产物。学习内容不得将缓解判定条件变成停药练习；不能把六路径、收尾、混燃区和能力更新转成未经验证的临床分诊或处方算法。智能体宜解释章节、提示出处、辨明未知和整理待询问问题；其本地运行或可打开不等于具有患者监护、医疗联络或临床决策资格。急性危险场景应保留直接求助通道，不能用继续问答延误处理。

## 核验来源

下表记录本轮独立核对的来源及范围。完整网页访问状态、检索参考号与补丁映射保存在两个 JSON 文件中。

| 来源 | 核验用途 |
|---|---|
| [WHO Rehabilitation factsheet](https://www.who.int/news-room/fact-sheets/detail/rehabilitation) | 功能、环境调整、辅助用品、个体目标与药物示例均在原文；年份2024正确。 |
| [WHO Rehabilitation questions and answers](https://www.who.int/news-room/questions-and-answers/item/rehabilitation) | 恢复、维持和改善功能，以及个体化目标和干预；年份2024正确。 |
| [2025 AHA/ACC adult high blood pressure guideline Table 4](https://www.jacc.org/doi/10.1016/j.jacc.2025.05.007) | stage1阈值、至少两次场合均值和取较高类别原则。 |
| [国家基层高血压防治管理指南2025版](https://cs.medjournals.cn/article/doi/full/10.3760/cma.j.cn112148-20250401-00234) | 来源标题与指南身份已确认；诊断细节沿用原证据索引，未称本轮已通读原指南。 |
| [2024 ESC Guidelines for management of elevated BP and hypertension](https://academic.oup.com/eurheartj/article/45/38/3912/7741010) | 多数接受治疗成人的120—129目标及耐受、体位低血压、85岁以上、中重度脆弱等例外；书稿限定基本准确。 |
| [NICE Hypertension in adults recommendations](https://www.nice.org.uk/guidance/ng136/chapter/recommendations) | 80岁及以上诊室低于150/90目标、脆弱共病临床判断、体位症状和站立血压评价。；原刊页面确认2026年2月26日更新，保留正文2026更新年。 |
| [NICE ME/CFS recommendations 1.11.9–1.11.16](https://www.nice.org.uk/guidance/ng206/chapter/recommendations) | 不把固定递增运动或运动治愈用于ME/CFS；原稿没有泛化成全体慢性病运动禁忌。 |
| [MRC/BHF Heart Protection Study](https://pubmed.ncbi.nlm.nih.gov/12114036/) | 20,536高风险成人、五年治疗、首次重大血管事件19.8%与25.2%；5.4个百分点计算正确。 |
| [Long-term follow-up of OPTiMISE randomised controlled trial](https://pubmed.ncbi.nlm.nih.gov/39094592/) | ≥80岁、SBP<150、≥2降压药、移除1药；中位4年随访未发现住院或死亡增加证据；书稿未夸为普遍安全。 |
| [2026 Guideline on the Management of Dyslipidemia](https://professional.heart.org/en/science-news/2026-guideline-on-the-management-of-dyslipidemia) | 该指南真实存在；扩及残粒与Lp(a)，选择性apoB及总体风险；未发现未来虚构指南。 |
| [ADA 2026 Section 6 Glycemic Goals Hypoglycemia and Hyperglycemic Crises](https://diabetesjournals.org/docm-care/article/doi/10.2337/doc26-a006/164631/Section-6-Glycemic-Goals-Hypoglycemia-and) | 低血糖<3.9 mmol/L；严重事件依据需他人援助而不由单一读数决定；与正文一致。 |
| [ADA 2026 Section 16 Diabetes Care in the Hospital](https://diabetesjournals.org/care/article/49/Supplement_1/S339/163925/16-Diabetes-Care-in-the-Hospital-Standards-of-Care) | DKA/HHS急症、可重叠、正常血糖性DKA及SGLT2背景；正文保留紧急医疗通道。 |
| [Consensus Report Definition and Interpretation of Remission in Type 2 Diabetes](https://diabetesjournals.org/care/article/44/10/2438/138556/Consensus-Report-Definition-and-Interpretation-of) | HbA1c<6.5%、停降糖药至少3月；生活方式开始至少6月后评价；持续至少年度评估；原稿年度随访已写明。 |
| [5-year follow-up of DiRECT extension study](https://pubmed.ncbi.nlm.nih.gov/38423026/) | 5年延长支持组有结果85人中11人缓解；原稿正确区分与初始149人分母。 |
| [TRIPOD+AI statement](https://www.bmj.com/content/385/bmj-2023-078378) | 覆盖回归及机器学习；2024清单取代2015清单。 |
| [Breathing exercises for stress](https://www.nhs.uk/mental-health/self-help/guides-tools-and-activities/breathing-exercises-for-stress/) | 舒适、不强迫、轻柔规律的呼吸练习；书中[NHS 2026]与页面复核年一致。 |
| [Statins](https://www.nhs.uk/medicines/statins/) | 他汀与特定药物、草药、食物饮料的相互作用；自行停药不能据功能改善决定；书中2026年与页面复核年一致。 |
| [7. Diabetes Technology: Standards of Care in Diabetes—2026](https://diabetesjournals.org/care/article/49/Supplement_1/S150/163922) | 建议7.10：CGM使用者仍须能取得BGM；疑似读数不准、预热、传输中断等情境需要备用检测。 |
| [9. Pharmacologic Approaches to Glycemic Treatment: Standards of Care in Diabetes—2026](https://diabetesjournals.org/care/article/49/Supplement_1/S183/163934/9-Pharmacologic-Approaches-to-Glycemic-Treatment) | 建议9.10：特定2型糖尿病与慢性肾病人群的有证据药物承担心肾结局任务，其使用不只依赖A1C。 |
| [Saturated fatty acid and trans-fatty acid intake for adults and children: WHO guideline](https://www.who.int/publications/i/item/9789240073630) | SFA recommendation 3与TFA recommendation 3的替代营养素范围不完全相同；TFA备注不排斥碳水化合物替代，但正式推荐列PUFA与主要植物来源MUFA。 |

## 编校边界

本记录支持文字与证据对应关系的内部审校，不替代持证临床人员对具体患者的诊断、风险分层和治疗调整，也不替代对拟议 SDE 干预开展独立研究。事实错误、遗漏和表述精度可以在后续版本继续修订；没有把未发现的问题等同于保证不存在问题。
