属性纠缠与科研新典范 全书统稿版v1.1
王德生 著 德麦国际出版社 第379卷 ISBN979-8-90690-485-0 US$35
正文323304汉字，8编40章，导论和结语另列，73条参考资料。
chapters为章节Markdown。正文[@KEY]与refs条目对应，排版后的统一编号见resolved_references.json。数学公式保留TeX源，在Word中为29个原生数学对象。
