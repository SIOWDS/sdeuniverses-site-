"""Judgment ledger demonstration; not a theorem prover or a secure authority.

Certificates are assertions supplied by an external trusted checker. This prototype
checks workflow consistency only. A forged 'passed' certificate is not detected.
Python 3.10+; standard library only.
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from enum import Enum
from hashlib import sha256
from pathlib import Path
import json
import os
import tempfile

class JudgmentError(ValueError):
    pass

class Status(str, Enum):
    CANDIDATE = 'candidate'
    VERIFIED = 'verified'
    REFUTED = 'refuted'
    NEEDS_REVIEW = 'needs_review'

class EvidenceKind(str, Enum):
    HUMAN_PROOF = 'human_proof'
    FORMAL_CHECK = 'formal_check'
    TEST_ONLY = 'test_only'

@dataclass(frozen=True)
class Certificate:
    target_digest: str
    kind: EvidenceKind
    reference: str
    semantic_match: bool = False
    obligations_closed: bool = False

@dataclass
class Node:
    node_id: str
    statement: str
    context: tuple[str, ...] = ()
    required_assumptions: tuple[str, ...] = ()
    dependencies: tuple[str, ...] = ()
    mathematical: bool = True
    revision: int = 1
    evidence_epoch: int = 0
    status: Status = Status.CANDIDATE
    certificate: Certificate | None = None
    notes: list[str] = field(default_factory=list)

class Ledger:
    def __init__(self) -> None:
        self._nodes: dict[str, Node] = {}
        self.events: list[dict[str, object]] = []

    def get(self, node_id: str) -> Node:
        try:
            return self._nodes[node_id]
        except KeyError as exc:
            raise JudgmentError(f'Unknown node: {node_id}') from exc

    def _check_dependencies(self, node_id: str, dependencies: tuple[str, ...]) -> None:
        if len(dependencies) != len(set(dependencies)):
            raise JudgmentError('Duplicate dependencies are not accepted.')
        for dep in dependencies:
            if dep == node_id:
                raise JudgmentError('Self dependency is not accepted.')
            self.get(dep)
        graph = {k: n.dependencies for k, n in self._nodes.items()}
        graph[node_id] = dependencies
        visiting: set[str] = set()
        done: set[str] = set()
        def visit(k: str) -> None:
            if k in visiting:
                raise JudgmentError('Unexplained cyclic dependency.')
            if k in done:
                return
            visiting.add(k)
            for d in graph[k]:
                visit(d)
            visiting.remove(k)
            done.add(k)
        for k in graph:
            visit(k)

    def add(self, node_id: str, statement: str, *, context: tuple[str, ...] = (),
            required_assumptions: tuple[str, ...] = (),
            dependencies: tuple[str, ...] = (), mathematical: bool = True) -> None:
        if not node_id.strip() or not statement.strip():
            raise JudgmentError('Nonempty identity and statement required.')
        if node_id in self._nodes:
            raise JudgmentError('Existing identity cannot be silently overwritten.')
        self._check_dependencies(node_id, dependencies)
        self._nodes[node_id] = Node(node_id=node_id, statement=statement,
            context=tuple(context), required_assumptions=tuple(required_assumptions),
            dependencies=tuple(dependencies), mathematical=mathematical)
        self.events.append({'event': 'add', 'node': node_id, 'revision': 1})

    def digest(self, node_id: str) -> str:
        n = self.get(node_id)
        payload = {'id': n.node_id, 'statement': n.statement,
            'context': sorted(n.context), 'required': sorted(n.required_assumptions),
            'revision': n.revision, 'mathematical': n.mathematical,
            'dependencies': [(d, self.get(d).revision, self.get(d).evidence_epoch)
                             for d in n.dependencies]}
        raw = json.dumps(payload, ensure_ascii=False, sort_keys=True).encode('utf-8')
        return sha256(raw).hexdigest()

    def _invalidate_dependents(self, node_id: str, reason: str) -> None:
        affected = {node_id}
        while True:
            new = {k for k, n in self._nodes.items()
                   if any(d in affected for d in n.dependencies)} - affected
            if not new:
                break
            affected |= new
        for k in sorted(affected - {node_id}):
            n = self.get(k)
            n.status = Status.NEEDS_REVIEW
            n.certificate = None
            n.notes.append(reason)
            self.events.append({'event': 'invalidate', 'node': k, 'reason': reason})

    def revise(self, node_id: str, *, statement: str | None = None,
               context: tuple[str, ...] | None = None,
               required_assumptions: tuple[str, ...] | None = None,
               dependencies: tuple[str, ...] | None = None) -> None:
        n = self.get(node_id)
        if statement is not None and not statement.strip():
            raise JudgmentError('Empty replacement statement.')
        deps = n.dependencies if dependencies is None else tuple(dependencies)
        self._check_dependencies(node_id, deps)
        old_statement = n.statement
        if statement is not None:
            n.statement = statement
        if context is not None:
            n.context = tuple(context)
        if required_assumptions is not None:
            n.required_assumptions = tuple(required_assumptions)
        n.dependencies = deps
        n.revision += 1
        n.status = Status.NEEDS_REVIEW
        n.certificate = None
        self.events.append({'event': 'revise', 'node': node_id,
                            'revision': n.revision, 'old_statement': old_statement,
                            'new_statement': n.statement})
        self._invalidate_dependents(node_id, f'Dependency {node_id} revised.')

    def verify(self, node_id: str, certificate: Certificate) -> None:
        n = self.get(node_id)
        if n.status == Status.REFUTED:
            raise JudgmentError('Refuted goal requires explicit revision or a new goal.')
        if not certificate.reference.strip():
            raise JudgmentError('Evidence reference required.')
        if certificate.target_digest != self.digest(node_id):
            raise JudgmentError('Stale or mismatched certificate.')
        if not certificate.semantic_match:
            raise JudgmentError('Goal meaning has not been confirmed.')
        if not certificate.obligations_closed:
            raise JudgmentError('Proof obligations remain open.')
        if n.mathematical and certificate.kind == EvidenceKind.TEST_ONLY:
            raise JudgmentError('Finite testing cannot certify this mathematical goal.')
        missing = set(n.required_assumptions) - set(n.context)
        if missing:
            raise JudgmentError(f'Explicit conditions missing: {sorted(missing)}')
        for dep in n.dependencies:
            dn = self.get(dep)
            if dn.status != Status.VERIFIED or dn.certificate is None:
                raise JudgmentError(f'Dependency not verified: {dep}')
            if dn.certificate.target_digest != self.digest(dep):
                raise JudgmentError(f'Dependency certificate stale: {dep}')
        self._invalidate_dependents(node_id, f'Evidence for {node_id} replaced.')
        n.certificate = certificate
        n.status = Status.VERIFIED
        n.evidence_epoch += 1
        self.events.append({'event': 'verify', 'node': node_id,
                            'revision': n.revision, 'kind': certificate.kind.value,
                            'reference': certificate.reference})

    def refute(self, node_id: str, reference: str) -> None:
        if not reference.strip():
            raise JudgmentError('Refutation reference required.')
        n = self.get(node_id)
        n.status = Status.REFUTED
        n.certificate = None
        n.notes.append(reference)
        self.events.append({'event': 'refute', 'node': node_id, 'reference': reference})
        self._invalidate_dependents(node_id, f'Dependency {node_id} refuted.')

    def export(self, path: str | Path) -> None:
        destination = Path(path)
        destination.parent.mkdir(parents=True, exist_ok=True)
        data = {'warning': 'Workflow demonstration only; external evidence is not re-proved.',
                'nodes': {k: asdict(v) for k, v in self._nodes.items()}, 'events': self.events}
        tmp: str | None = None
        try:
            with tempfile.NamedTemporaryFile('w', encoding='utf-8', delete=False,
                    dir=destination.parent, suffix='.tmp') as fh:
                tmp = fh.name
                json.dump(data, fh, ensure_ascii=False, indent=2)
            os.replace(tmp, destination)
        finally:
            if tmp and os.path.exists(tmp):
                os.unlink(tmp)
