"""Synthetic unit tests for state gates, not tests of AI mathematical ability."""
import json
from pathlib import Path
import tempfile
import unittest
from ledger import Ledger, Certificate, EvidenceKind, Status, JudgmentError

def cert(ledger, node_id, **changes):
    values = dict(target_digest=ledger.digest(node_id), kind=EvidenceKind.HUMAN_PROOF,
                  reference='synthetic test fixture: externally asserted evidence',
                  semantic_match=True, obligations_closed=True)
    values.update(changes)
    return Certificate(**values)

class LedgerTests(unittest.TestCase):
    def test_01_valid_leaf_and_composition(self):
        l=Ledger(); l.add('A','P'); l.verify('A',cert(l,'A'))
        l.add('B','Q',dependencies=('A',)); l.verify('B',cert(l,'B'))
        self.assertEqual(l.get('B').status,Status.VERIFIED)
    def test_02_unverified_dependency_blocked(self):
        l=Ledger(); l.add('A','P'); l.add('B','Q',dependencies=('A',))
        with self.assertRaises(JudgmentError): l.verify('B',cert(l,'B'))
    def test_03_missing_condition_blocked(self):
        l=Ledger(); l.add('A','Q',context=('P',),required_assumptions=('P','H'))
        with self.assertRaises(JudgmentError): l.verify('A',cert(l,'A'))
    def test_04_target_revision_rejects_old_certificate(self):
        l=Ledger(); l.add('A','P'); c=cert(l,'A'); l.revise('A',statement='Q')
        with self.assertRaises(JudgmentError): l.verify('A',c)
    def test_05_transitive_invalidation(self):
        l=Ledger(); l.add('A','P'); l.verify('A',cert(l,'A'))
        l.add('B','Q',dependencies=('A',)); l.verify('B',cert(l,'B'))
        l.add('C','R',dependencies=('B',)); l.verify('C',cert(l,'C'))
        l.revise('A',statement='P revised')
        self.assertEqual(l.get('B').status,Status.NEEDS_REVIEW)
        self.assertEqual(l.get('C').status,Status.NEEDS_REVIEW)
    def test_06_unrelated_branch_preserved(self):
        l=Ledger(); l.add('A','P'); l.add('U','unrelated'); l.verify('U',cert(l,'U'))
        l.revise('A',statement='Q')
        self.assertEqual(l.get('U').status,Status.VERIFIED)
    def test_07_cycles_blocked_without_mutation(self):
        l=Ledger(); l.add('A','P'); l.add('B','Q',dependencies=('A',))
        with self.assertRaises(JudgmentError): l.revise('A',dependencies=('B',))
        self.assertEqual(l.get('A').dependencies,())
    def test_08_finite_test_cannot_pass_math_goal(self):
        l=Ledger(); l.add('A','for all n: P(n)')
        with self.assertRaises(JudgmentError):
            l.verify('A',cert(l,'A',kind=EvidenceKind.TEST_ONLY))
    def test_09_test_allowed_for_explicit_test_task(self):
        l=Ledger(); l.add('A','check fixed fixture',mathematical=False)
        l.verify('A',cert(l,'A',kind=EvidenceKind.TEST_ONLY))
        self.assertEqual(l.get('A').status,Status.VERIFIED)
    def test_10_semantic_mismatch_blocked(self):
        l=Ledger(); l.add('A','P')
        with self.assertRaises(JudgmentError): l.verify('A',cert(l,'A',semantic_match=False))
    def test_11_open_obligation_blocked(self):
        l=Ledger(); l.add('A','P')
        with self.assertRaises(JudgmentError): l.verify('A',cert(l,'A',obligations_closed=False))
    def test_12_refutation_requires_explicit_revision(self):
        l=Ledger(); l.add('A','all even integers divisible by 4'); l.refute('A','counterexample 2')
        with self.assertRaises(JudgmentError): l.verify('A',cert(l,'A'))
        l.add('A2','all multiples of 4 are even')
        l.verify('A2',cert(l,'A2')); self.assertEqual(l.get('A').status,Status.REFUTED)
    def test_13_no_silent_overwrite(self):
        l=Ledger(); l.add('A','P')
        with self.assertRaises(JudgmentError): l.add('A','Q')
    def test_14_unknown_dependency_blocked(self):
        l=Ledger()
        with self.assertRaises(JudgmentError): l.add('A','P',dependencies=('missing',))
    def test_15_export_has_versions_and_events(self):
        l=Ledger(); l.add('A','P'); l.revise('A',statement='Q')
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'ledger.json'; l.export(p); data=json.loads(p.read_text())
            self.assertEqual(data['nodes']['A']['revision'],2)
            self.assertEqual(data['events'][1]['old_statement'],'P')
    def test_16_reverification_requires_new_downstream_evidence(self):
        l=Ledger(); l.add('A','P'); l.verify('A',cert(l,'A'))
        l.add('B','Q',dependencies=('A',)); old=cert(l,'B'); l.verify('B',old)
        l.verify('A',cert(l,'A'))
        with self.assertRaises(JudgmentError): l.verify('B',old)
        self.assertEqual(l.get('B').status,Status.NEEDS_REVIEW)
    def test_17_reference_required(self):
        l=Ledger(); l.add('A','P')
        with self.assertRaises(JudgmentError): l.verify('A',cert(l,'A',reference=''))
    def test_18_identifier_not_coerced_to_integer(self):
        l=Ledger(); l.add('0012','first'); l.add('12','second')
        self.assertNotEqual(l.get('0012').statement,l.get('12').statement)
    def test_19_this_is_not_a_prover(self):
        l=Ledger(); l.add('A','2 = 5')
        # Deliberately dishonest fixture: demonstrates the explicit trust boundary.
        l.verify('A',cert(l,'A'))
        self.assertEqual(l.get('A').status,Status.VERIFIED)

if __name__ == '__main__':
    unittest.main(verbosity=2)
