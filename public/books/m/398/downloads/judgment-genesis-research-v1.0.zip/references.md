# 参考文献与资料状态

本书以王德生博士在本项目中的立题与修订为理论起点。SDE资料用于核对该框架的概念和方法，不作为工具历史、认知实验或AI能力的独立实证。其他资料限于各处实际论述所需范围。以下在线资料访问日期均为2026年10月8日；持续更新的技术文档以本次读取内容为准。

## [R1] SDE价值发生学

王德生：《SDE价值发生学：四个三角与真善美的完整发生》，德麦国际专著第255号。用于四个发生截面、失配诊断、回写与重新发生的理论依据。“人的判断＋刀的封装判断”及本书的具体工程提案，以本项目的最新立题和本书论证为准，不倒写成该书已经验证的结论。

https://sdeuniverses.com/books/m/255/text/

## [R2] 延展心智

Clark, Andy, and David J. Chalmers. “The Extended Mind.” Analysis 58, no. 1 (1998): 10–23。作者网站全文。用于耦合认知系统的近邻比较，不据此推断一切工具都具有同一种认知地位或意识。

https://consc.net/papers/extended.html

## [R3] Lean证明构造与验证

Lean语言参考文档：“Elaboration and Compilation”；“Validating a Lean Proof”。用于区分证明构造、内核检查、命题含义及增强核验方式。本项目没有运行Lean形式证明实验，正文中的数学推导为纸面论证。

https://lean-lang.org/doc/reference/latest/Elaboration-and-Compilation/

https://lean-lang.org/doc/reference/latest/ValidatingProofs/

## [R4] SDE三方程

王德生：《SDE三方程导论》，第51号，第2章及第39章。用于三方程、生成算子、具体领域落实和理论增量的范围说明。

https://sdeuniverses.com/books/m/51/chapter-02/

https://sdeuniverses.com/books/m/51/chapter-39/

## [R5] 六路径方法论

《六路径方法论入门》，SDE专著第52号，第3章及第27章。用于D、E的解释与路径中后续维度对先前判断的实质校正。不同路径或多个智能体的一致意见，不在本书中被视为自动正确。

https://sdeuniverses.com/books/m/52/chapter-03/

https://sdeuniverses.com/books/m/52/chapter-27/

## [R6] SDE三原理

《从三视角的123原理到SDE的三原理》，SDE网站“三维度九宫格”栏目。用于三种相位及回写的对称展开。第三维改变作为候选重组机制，不等于所有矛盾都必然得到解决。

https://sdeuniverses.com/column/ontology-grid/123-to-three-principles/

## [R7] 模块划分与信息隐藏

Parnas, David L. “On the Criteria To Be Used in Decomposing Systems into Modules.” Communications of the ACM 15, no. 12 (1972): 1053–1058。使用大学托管的原文副本；DOI：10.1145/361598.361623。用于与设计决策的信息隐藏及模块划分相比较，不把SDE封装直接等同于软件模块。

https://wstomv.win.tue.nl/edu/2ip30/references/criteria_for_modularization.pdf

## [R8] 驾驶舱中的分布式认知

Hutchins, Edwin. “How a Cockpit Remembers Its Speeds.” Cognitive Science 19, no. 3 (1995): 265–288。DOI：10.1207/s15516709cog1903_1。本书使用出版方摘要所支持的系统认知分析方向，未据此开展航空操作指导，也未声称本项目通读并复核该论文的全部研究细节。

https://onlinelibrary.wiley.com/doi/abs/10.1207/s15516709cog1903_1

## [R9] 产品验证

NASA Systems Engineering Handbook，在线第5.3节“Product Verification”。用于设计要求、验证方式和实际检查之间的区分，不作为本书所设技术案例已经通过工程验收的证据。

https://www.nasa.gov/reference/5-3-product-verification/

## [R10] 产品确认与重新检验

NASA Systems Engineering Handbook，在线第5.4节“Product Validation”。用于预期使用、系统层级与改动后重新验证的讨论。正文中的软件制作和数学讲义音频案例均为明确构造的分析情境。

https://www.nasa.gov/reference/5-4-product-validation/

## [R11] AI风险管理的邻近框架

National Institute of Standards and Technology. “AI Risk Management Framework.” 官方框架入口。用于与AI设计、开发、使用及评价中的风险管理工作比较。该自愿框架不被写成法律要求；本书未评述所有后续版本和行业资料。

https://www.nist.gov/itl/ai-risk-management-framework

## [R12] 反思性思维

Dewey, John. How We Think. 1910。Project Gutenberg公开原文，电子书编号37423。用于反思、疑难、依据和检验之间关系的近邻比较，不把杜威的方法简化为僵硬步骤表。

https://www.gutenberg.org/cache/epub/37423/pg37423-images.html

## [R13] Lean公理与依赖

Lean语言参考文档：“Axioms”。用于公理、证明依赖及未完成证明占位的区分。当前命题的信任边界仍须明确，本项目未运行相关命令进行形式核验。

https://lean-lang.org/doc/reference/latest/Axioms/

## [R14] 本书的前序项目记录

王德生：《AI时代的判断力发生学导论》母题修订与连续写作规程v2.0；正文第01批（导论、第一章），2026年10月8日。原文件为judgment_genesis_workflow_v2.docx与judgment_genesis_batch01.docx。用于追踪本项目从“守住个人判断”转向“判断力本来就是复合能力”的实际立题修订，不作为外部实证资料。

## [R15] 本书判断台账研究原型与测试记录

《AI时代的判断力发生学导论》写作项目：prototype/ledger.py、prototype/test_ledger.py及prototype/test_output.txt，2026年10月8日。十九项标准库单元测试在本项目工作环境中实际运行通过；测试对象是状态与依赖管理，并非AI数学能力。第十九项刻意展示外部证明凭证被信任时的局限。代码、说明和原始测试输出随写作包提供。

## [R16] 信息流与系统认知

Hutchins, Edwin. “The Cognitive Consequences of Patterns of Information Flow.” 加州大学圣迭戈分校作者网页公开稿。此处不推定未核实的出版年份或正式发表版本。用于设计选择、信息流与系统认知效果关系的比较。

https://pages.ucsd.edu/~ehutchins/documents/informationflow.pdf
