# 知返 · 智能体配置与全书知识源

原书：《孩子的数学理解是怎样发生的》；作者陈春妮；第531卷网络发布版；ISBN 979-8-90690-531-4。

## 怎样维护或迁移

1. 以 agent-config.json 读取身份和来源路径，以 system_prompt.txt 配置系统提示词。
2. 按用户选定章节载入 knowledge/chapters/ 中的对应JSON；核对UTF-8正文SHA-256后再提供给模型。
3. knowledge/book-source.json保存导论、25章、结语、6附录与编题定位；knowledge/images保留9幅原图。若平台不支持图像输入，不得宣称模型已读图。
4. keypoints.json是13组有来源的原文节录；rag.json是12部真实站内专著的编辑比较选材，各有原文链接与段落指纹。
5. learning.json和learning-design.json保留25个学习单元、8次共读及6张记录表；原书与配套设计须分开标识。
6. 模型服务及密钥由维护者在目标平台自行配置。本包不绑定第三方账户，不包含任何密钥、儿童个人资料或读者学习档案。

## 知识边界

本包支持阅读、检索和教研，不代表作者本人回应，不是学习效果或儿童能力的认证。当前发布完成界面、来源身份和模拟请求验证，没有声称进行过真实付费模型或教学效果实验。

在线入口：https://sdeuniverses.com/books/m/531/agent/dialogue.html
