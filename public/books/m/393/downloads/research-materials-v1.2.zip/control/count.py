from pathlib import Path
import re,json
ROOT=Path(__file__).resolve().parents[1]
HAN=re.compile(r'[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\U00020000-\U0002ebef]')
def content_text(text):
    # Headings, source notes and publication matter do not enter main-body count.
    body=text.split('\n## 本章来源')[0].split('\n## 来源说明')[0]
    body='\n'.join(x for x in body.splitlines() if not x.lstrip().startswith('#'))
    body=re.sub(r'\[[A-Z]+\d+(?:[^\]]*)\]','',body)
    return body
rows=[]
for p in sorted((ROOT/'manuscript').glob('*.md')):
 t=p.read_text();b=content_text(t)
 rows.append({'file':p.name,'cjk_body':len(HAN.findall(b)),'chars_nonspace':len(re.sub(r'\s','',b)),'sections':len(re.findall(r'^## \d+\.\d+',t,re.M))})
(ROOT/'control/counts.json').write_text(json.dumps({'main_cjk':sum(x['cjk_body'] for x in rows),'files':rows},ensure_ascii=False,indent=2))
for x in rows:print(x['file'],x['cjk_body'],x['sections'])
print('MAIN_CJK=',sum(x['cjk_body'] for x in rows))
