"""Finite demonstrations supporting the manuscript; not empirical educational data."""
from __future__ import annotations
from itertools import product, combinations
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
import json, os, time
ROOT=Path(__file__).resolve().parents[1]

def rotation():
    t=time.time();R=[((d+e)%4,d,e) for d,e in product(range(4),repeat=2)]
    assert all(d==(s-e)%4 and e==(s-d)%4 for s,d,e in R)
    amb={}
    for s,d,e in R:amb.setdefault((s%2,e),set()).add(d)
    return {'test':'rotation_mod4','pid':os.getpid(),'start':t,'end':time.time(),'triples':len(R),'all_three_equations':True,'coarse_output_input_pairs':len(amb),'coarse_ambiguous_pairs':sum(len(x)>1 for x in amb.values()),'scope':'mod4 encoding, parity output loses orientation information'}

def budgets():
    t=time.time();n=4;edges=list(combinations(range(n),2));nontrans=0;tests=0
    for mask in range(64):
        d=[[0 if i==j else 99 for j in range(n)] for i in range(n)]
        for k,(a,b) in enumerate(edges):
            if mask>>k&1:d[a][b]=d[b][a]=1
        for k in range(n):
            for i in range(n):
                for j in range(n):d[i][j]=min(d[i][j],d[i][k]+d[k][j])
        if any(d[x][y]<=2 and d[y][z]<=2 and d[x][z]>2 for x,y,z in product(range(n),repeat=3)):nontrans+=1
        for x,y,z in product(range(n),repeat=3):
            for a,b in product(range(4),repeat=2):
                if d[x][y]<=a and d[y][z]<=b:assert d[x][z]<=a+b
                tests+=1
    return {'test':'budgeted_paths','pid':os.getpid(),'start':t,'end':time.time(),'graphs':64,'implications_checked':tests,'graphs_where_two_step_relation_not_transitive':nontrans,'scope':'all labelled four-vertex undirected simple graphs; budgets0..3'}

def latin_counter():
    t=time.time();n=3;op=lambda a,b:(-a-b)%n
    table=[[op(a,b) for b in range(n)] for a in range(n)]
    assert all(len(set(row))==3 for row in table)
    assert all(len({table[a][b] for a in range(n)})==3 for b in range(n))
    w=next((a,b,c) for a,b,c in product(range(n),repeat=3) if op(op(a,b),c)!=op(a,op(b,c)))
    return {'test':'latin_nonassociative','pid':os.getpid(),'start':t,'end':time.time(),'table':table,'witness':w,'left':op(op(w[0],w[1]),w[2]),'right':op(w[0],op(w[1],w[2])),'scope':'one explicit quasigroup, demonstrating mutual solvability does not force associativity'}

def weighted_triangles():
    t=time.time();edges=[(0,1),(0,2),(1,2)];bad=0;metric=0;pseudo=0
    for ws in product(range(4),repeat=3):
        d=[[0]*3 for _ in range(3)]
        for (a,b),w in zip(edges,ws):d[a][b]=d[b][a]=w
        if any(d[a][c]>d[a][b]+d[b][c] for a,b,c in product(range(3),repeat=3)):bad+=1
        for k in range(3):
            for i in range(3):
                for j in range(3):d[i][j]=min(d[i][j],d[i][k]+d[k][j])
        assert all(d[a][c]<=d[a][b]+d[b][c] for a,b,c in product(range(3),repeat=3))
        if all(d[a][b]>0 for a,b in edges):metric+=1
        else:pseudo+=1
    return {'test':'weighted_shortest_paths','pid':os.getpid(),'start':t,'end':time.time(),'weight_assignments':64,'direct_weights_violating_triangle':bad,'shortest_path_metrics':metric,'shortest_path_pseudometrics_not_metrics':pseudo,'scope':'complete three-vertex graphs with integer weights0..3'}

def one(name):return globals()[name]()
if __name__=='__main__':
    with ProcessPoolExecutor(max_workers=4) as ex:r=list(ex.map(one,['rotation','budgets','latin_counter','weighted_triangles']))
    (ROOT/'checks/advanced_results.json').write_text(json.dumps(r,ensure_ascii=False,indent=2))
    for x in r:print(x)
