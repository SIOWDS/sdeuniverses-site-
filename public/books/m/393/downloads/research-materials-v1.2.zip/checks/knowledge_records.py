"""A finite, explicitly conventional record system, not a truth oracle."""
from __future__ import annotations
from collections import deque
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
State=tuple[bool,bool,bool,bool] # checked A, checked B, accepted A, accepted B
START=(False,False,False,False)
ACTIONS=('check_A','check_B','accept_A','accept_B','withdraw_A','withdraw_B')
def invariant(s:State)->bool:
    ca,cb,aa,ab=s
    return (not aa or ca) and (not ab or cb) and (not ab or aa)
def step(s:State,a:str)->State|None:
    ca,cb,aa,ab=s
    if a=='check_A' and not ca:return (True,cb,aa,ab)
    if a=='check_B' and not cb:return (ca,True,aa,ab)
    if a=='accept_A' and ca and not aa:return (ca,cb,True,ab)
    if a=='accept_B' and cb and aa and not ab:return (ca,cb,aa,True)
    if a=='withdraw_A' and (ca or aa):return START
    if a=='withdraw_B' and (cb or ab):return (ca,False,aa,False)
    return None

def run(s:State,events:tuple[str,...])->State:
    for a in events:
        nxt=step(s,a)
        if nxt is None:raise ValueError((s,a))
        s=nxt
    return s

def paths_from(s:State,n:int):
    yield (),s
    if n:
        for a in ACTIONS:
            z=step(s,a)
            if z is not None:
                for tail,t in paths_from(z,n-1):yield (a,)+tail,t

if __name__=='__main__':
    todo=deque([START]);seen={START};edges=[]
    while todo:
        s=todo.popleft()
        assert invariant(s)
        for a in ACTIONS:
            t=step(s,a)
            if t is not None:
                assert invariant(t);edges.append((s,a,t))
                if t not in seen:seen.add(t);todo.append(t)
    all_paths=list(paths_from(START,6))
    for events,t in all_paths:assert run(START,events)==t and invariant(t)
    assoc=0
    for s in seen:
        for u,t in paths_from(s,2):
            for v,w in paths_from(t,2):
                for z,r in paths_from(w,2):
                    assert (u+v)+z==u+(v+z)
                    assert run(s,u+v+z)==r
                    assoc+=1
    h1=('check_A','accept_A');h2=h1+('check_B','accept_B');h3=h2+('withdraw_A',)
    result={'title':'versioned_retractable_record_model','scope':'two claims, B depends on A; check flags are protocol states, not truth','reachable_states':len(seen),'transitions':len(edges),'valid_histories_length_at_most_6':len(all_paths),'composable_path_triples_checked':assoc,'all_invariants_passed':True,'states':[list(s) for s in sorted(seen)],'example_histories':[{'events':h,'final_state':run(START,h)} for h in (h1,h2,h3)],'limitations':['finite declared model only','no human learning experiment','no independent agent peer review','records do not establish proposition truth']}
    (ROOT/'checks/knowledge_records_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps(result,ensure_ascii=False,indent=2))
