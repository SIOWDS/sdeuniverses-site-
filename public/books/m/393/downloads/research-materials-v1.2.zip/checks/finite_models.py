"""Reproducible finite checks. These are finite enumerations, not general proofs."""
from __future__ import annotations
from concurrent.futures import ProcessPoolExecutor
from itertools import product, combinations
from pathlib import Path
import json,os,time
ROOT=Path(__file__).resolve().parents[1]

def relation_checks():
    start=time.time()
    R=[(s,d,e) for s,d,e in product(range(3),repeat=3) if s==(d+e)%3]
    projections={}
    for name,k in [('DE_to_S',0),('SE_to_D',1),('SD_to_E',2)]:
        dic={}
        for t in R:dic.setdefault(tuple(t[j] for j in range(3) if j!=k),set()).add(t[k])
        projections[name]={'input_pairs':len(dic),'unique':all(len(v)==1 for v in dic.values())}
    hist={}
    for f,g,h in product(range(16),repeat=3):
        n=sum(s==((f>>(d*2+e))&1) and d==((g>>(s*2+e))&1) and e==((h>>(s*2+d))&1) for s,d,e in product(range(2),repeat=3))
        hist[n]=hist.get(n,0)+1
    neg_solutions=[t for t in product(range(2),repeat=3) if t[0]==1-t[1] and t[1]==1-t[2] and t[2]==1-t[0]]
    assert not neg_solutions
    return {'test':'ternary_relations','pid':os.getpid(),'start':start,'end':time.time(),'valid_triples_mod3':R,'projection_checks':projections,'boolean_function_systems':4096,'solution_count_distribution':hist,'odd_negation_solutions':neg_solutions,'scope':'all 4096 triples of Boolean binary-input function tables; no empirical frequency claim'}

def graph_checks():
    start=time.time(); n=4; edges=list(combinations(range(n),2));passed=0;direct_nontransitive=0
    for mask in range(1<<len(edges)):
        R={(i,i) for i in range(n)}
        for k,(a,b) in enumerate(edges):
            if mask&(1<<k):R|={(a,b),(b,a)}
        if any((a,b) in R and (b,c) in R and (a,c) not in R for a,b,c in product(range(n),repeat=3)):direct_nontransitive+=1
        C=set(R)
        for k in range(n):
            C|={(i,j) for i in range(n) for j in range(n) if (i,k) in C and (k,j) in C}
        assert all((i,i) in C for i in range(n))
        assert all((b,a) in C for a,b in C)
        assert all((a,c) in C for a,b in C for bb,c in C if b==bb)
        passed+=1
    cards=[('red','circle'),('red','square'),('blue','square'),('blue','triangle'),('green','triangle'),('green','circle')]
    R={(i,j) for i in range(6) for j in range(6) if cards[i][0]==cards[j][0] or cards[i][1]==cards[j][1]}
    C=set(R)
    for k in range(6):C|={(i,j) for i in range(6) for j in range(6) if (i,k) in C and (k,j) in C}
    return {'test':'graph_closure','pid':os.getpid(),'start':start,'end':time.time(),'graphs_checked':passed,'all_reachability_relations_equivalence':True,'direct_relations_not_transitive':direct_nontransitive,'six_card_direct_pairs_including_diagonal':len(R),'six_card_reachable_pairs':len(C),'scope':'64 labelled undirected simple graphs on four vertices; separate six-card case'}

def algebra_checks():
    start=time.time();n=3;assoc=monoid=comm=latin=groups=0
    example_nonassoc=None
    for t in product(range(n),repeat=n*n):
        iscomm=all(t[a*n+b]==t[b*n+a] for a,b in product(range(n),repeat=2))
        if iscomm:comm+=1
        islatin=all(len({t[a*n+b] for b in range(n)})==n for a in range(n)) and all(len({t[a*n+b] for a in range(n)})==n for b in range(n))
        if islatin:latin+=1
        witness=next(((a,b,c) for a,b,c in product(range(n),repeat=3) if t[t[a*n+b]*n+c]!=t[a*n+t[b*n+c]]),None)
        if witness is not None:
            if example_nonassoc is None:example_nonassoc={'table':t,'witness':witness}
            continue
        assoc+=1
        ids=[u for u in range(n) if all(t[u*n+a]==a==t[a*n+u] for a in range(n))]
        if ids:
            monoid+=1;u=ids[0]
            if all(any(t[a*n+b]==u==t[b*n+a] for b in range(n)) for a in range(n)):groups+=1
    return {'test':'three_element_operations','pid':os.getpid(),'start':start,'end':time.time(),'tables':n**(n*n),'associative':assoc,'with_associativity_and_identity':monoid,'commutative':comm,'latin':latin,'groups':groups,'nonassociative_example':example_nonassoc,'scope':'all labelled operations on a fixed three-element set; not counts up to isomorphism'}

def resource_checks():
    start=time.time()
    states=list(product([0,1],repeat=3));valid=[t for t in states if sum(t)<=2]
    projs={str(p):sorted({tuple(t[i] for i in p) for t in valid}) for p in combinations(range(3),2)}
    false_positive=[t for t in states if all(tuple(t[i] for i in p) in projs[str(p)] for p in combinations(range(3),2)) and t not in valid]
    assert false_positive==[(1,1,1)]
    return {'test':'global_resource_constraint','pid':os.getpid(),'start':start,'end':time.time(),'states':8,'valid_states':7,'pairwise_projections':projs,'pairwise_reconstruction_false_positive':false_positive,'scope':'three binary resource claims with capacity two; constructed example, not observed data'}

def run_one(name):return globals()[name]()
if __name__=='__main__':
    with ProcessPoolExecutor(max_workers=4) as ex:results=list(ex.map(run_one,['relation_checks','graph_checks','algebra_checks','resource_checks']))
    out=ROOT/'checks/finite_results.json';out.write_text(json.dumps(results,ensure_ascii=False,indent=2))
    for r in results:
        print(r['test'],'PID',r['pid'],'seconds',round(r['end']-r['start'],4))
        print({k:v for k,v in r.items() if k not in {'valid_triples_mod3','projection_checks','start','end','pid','scope','pairwise_projections'}})
