"""C7: finite checks for the v1.1 constructive extensions.
Only tests the explicitly enumerated finite systems. General proofs are in the book.
Python 3 standard library only; run: python checks/revision_models.py
"""
from __future__ import annotations
from itertools import product, combinations
from functools import lru_cache
from pathlib import Path
import json, hashlib
from datetime import datetime, timezone
ROOT=Path(__file__).resolve().parent

def compose(r:set[tuple[int,int]],q:set[tuple[int,int]])->set[tuple[int,int]]:
    return {(x,z) for x,y in r for yy,z in q if y==yy}

def closure(r:set[tuple[int,int]],n:int)->tuple[set[tuple[int,int]],int]:
    identity={(x,x) for x in range(n)}
    t=set(r);rounds=0
    while True:
        u=t|identity|compose(t,t)
        if u==t:return t,rounds
        assert t<u
        t=u;rounds+=1
        assert rounds<=n*n

def warshall(r:set[tuple[int,int]],n:int)->set[tuple[int,int]]:
    a=[[int(i==j or (i,j) in r) for j in range(n)] for i in range(n)]
    for k in range(n):
        for i in range(n):
            for j in range(n):a[i][j]=a[i][j] or (a[i][k] and a[k][j])
    return {(i,j) for i in range(n) for j in range(n) if a[i][j]}

def closure_checks():
    n=3;pairs=list(product(range(n),repeat=2));rels=[];closed=[];maxrounds=0
    for mask in range(1<<len(pairs)):
        r={p for k,p in enumerate(pairs) if mask>>k&1};c,steps=closure(r,n)
        assert r<=c and c==warshall(r,n) and closure(c,n)[0]==c
        assert {(i,i) for i in range(n)}<=c and compose(c,c)<=c
        rels.append(r);closed.append(c);maxrounds=max(maxrounds,steps)
    mono=0;minimality=0
    for i,r in enumerate(rels):
        for j,q in enumerate(rels):
            if r<=q:
                assert closed[i]<=closed[j];mono+=1
                if q==closed[j]:assert closed[i]<=q;minimality+=1
    return {'objects':n,'relations':len(rels),'monotonicity_subset_pairs':mono,'minimality_comparisons':minimality,'maximum_strict_update_rounds':maxrounds,'extensive_idempotent_reflexive_transitive_and_Warshall_agreement':True}

def cycle_checks():
    sync=lambda x:(x[1],x[2],x[0])
    def seq(x):
        s,d,e=x;s=d;d=e;e=s;return (s,d,e)
    syncpath=[(0,0,1)];seqpath=[(0,0,1)]
    for _ in range(3):syncpath.append(sync(syncpath[-1]));seqpath.append(seq(seqpath[-1]))
    fixed=[x for x in product(range(2),repeat=3) if sync(x)==x]
    assert fixed==[(0,0,0),(1,1,1)]
    assert syncpath==[(0,0,1),(0,1,0),(1,0,0),(0,0,1)]
    assert seqpath==[(0,0,1),(0,1,0),(1,0,1),(0,1,0)]
    return {'fixed_solutions':fixed,'synchronous_cycle':syncpath,'sequential_cycle':seqpath,'note':'Existence of simultaneous solutions does not ensure convergence of these chosen update schedules.'}

def quotient_checks():
    q=lambda n:int(n==1)
    assert q(0)==q(2) and q(1)!=q(3)
    paritypairs=0
    for x,y in product(range(13),repeat=2):
        if x%2==y%2:assert (x+1)%2==(y+1)%2;paritypairs+=1
    return {'length_one_partition_counterexample':[0,2],'equal_class_before':True,'unequal_class_after_append':True,'parity_pairs_checked':paritypairs,'scope':'Lengths 0..12; general quotient well-definedness theorem is proved in text.'}

def budget_checks():
    n=4;edges=list(combinations(range(n),2));queries=0;compositions=0
    for mask in range(1<<len(edges)):
        r=set()
        for k,(i,j) in enumerate(edges):
            if mask>>k&1:r|={(i,j),(j,i)}
        for B in range(4):
            states=list(product(range(n),range(B+1)));ix={s:i for i,s in enumerate(states)}
            er={(ix[(x,b)],ix[(y,b-1)]) for x,y in r for b in range(1,B+1)}
            ec=warshall(er,len(states))
            assert compose(ec,ec)<=ec
            for x,y in product(range(n),repeat=2):
                frontier={x};seen={x}
                for _ in range(B):
                    frontier={v for u,v in r if u in frontier};seen|=frontier
                encoded=any((ix[(x,B)],ix[(y,b)]) in ec for b in range(B+1))
                assert encoded==(y in seen);queries+=1
            compositions+=1
    return {'graphs':64,'budgets':[0,1,2,3],'expanded_graphs':compositions,'location_budget_queries':queries,'transitivity_in_expanded_state_graphs':True}

def derive(f:set[str],rules:list[tuple[set[str],str]])->set[str]:
    s=set(f)
    while True:
        t=s|{b for a,b in rules if a<=s}
        if t==s:return s
        s=t

def support_checks():
    rules=[({'A'},'C'),({'B'},'C'),({'C'},'D')]
    stages=[derive(f,rules) for f in [{'A','B'},{'B'},set()]]
    assert stages==[{'A','B','C','D'},{'B','C','D'},set()]
    andrules=[({'A','B'},'C'),({'C'},'D')]
    assert derive({'A'},andrules)=={'A'}
    assert derive({'A','B'},andrules)=={'A','B','C','D'}
    cyc=[({'A'},'B'),({'B'},'A')]
    assert derive(set(),cyc)==set() and derive({'A'},cyc)=={'A','B'}
    atoms=list('ABCD');sets=[{a for i,a in enumerate(atoms) if m>>i&1} for m in range(16)]
    count=0
    for rs in [rules,andrules,cyc]:
        for f in sets:
            c=derive(f,rs)
            assert f<=c and derive(c,rs)==c
            for q in sets:
                if f<=q:assert c<=derive(q,rs);count+=1
                if f<=q and all(not(a<=q) or b in q for a,b in rs):assert c<=q
    return {'alternative_support_withdrawal':[sorted(s) for s in stages],'conjunction_and_disjunction_distinguished':True,'unfounded_cycle_does_not_bootstrap':True,'seed_set_rule_combinations':48,'monotonicity_checks':count,'scope':'Finite positive rule support, not truth or causal identification.'}

@lru_cache(None)
def trees(branches:int):
    if branches==0:return (None,)
    return tuple((l,r) for k in range(branches) for l in trees(k) for r in trees(branches-1-k))
def tree_count(t):
    if t is None:return (1,0)
    l,b=tree_count(t[0]);ll,bb=tree_count(t[1]);return (l+ll,b+bb+1)
def tree_checks():
    count=0;by=[]
    for n in range(9):
        ts=trees(n);by.append(len(ts))
        for t in ts:
            leaf,b=tree_count(t);assert b==n and leaf==b+1;count+=1
    return {'binary_internal_node_bound':8,'shapes_by_internal_nodes':by,'total_shapes':count,'leaf_equals_binary_nodes_plus_one':True,'unary_counterexample':{'leaves':1,'all_internal_nodes':1,'old_formula_fails':True}}

if __name__=='__main__':
    results={
        'executed_utc':datetime.now(timezone.utc).isoformat(),
        'code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'equation_cycles':cycle_checks(),
        'finite_closure':closure_checks(),
        'quotient_operation':quotient_checks(),
        'budget_expansion':budget_checks(),
        'alternative_support':support_checks(),
        'structural_induction_examples':tree_checks(),
        'status':'all_assertions_passed',
        'independent_agent_calls':0,
        'limitation':'Finite constructive verification only. Does not establish the universal SDE-axiom thesis or educational effectiveness.'}
    (ROOT/'revision_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
    print(json.dumps(results,ensure_ascii=False,indent=2))
