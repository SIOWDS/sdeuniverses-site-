#!/usr/bin/env python3
"""Build this book only plus catalog and its three shelves. Never deploy.

Outputs under site/public mirror repository paths. Reference catalog and
agents snapshots can be replaced with latest main immediately before commit.
No existing book pages, agent records, workflows or search indexes are written.
"""
from pathlib import Path
import argparse, ast, datetime, hashlib, html, json, re, shutil, subprocess, tempfile

HERE=Path(__file__).resolve().parent
BOOK=HERE.parent
OUT=HERE/'public'
SLUG='mathematicians-future'
BASE='/books/'+SLUG+'/'
URL='https://sdeuniverses.com'+BASE
DEST=OUT/BASE.lstrip('/')
TITLE='面对AI的冲击，数学家走向何处？'
SUBTITLE='从常规解题到人—AI复合体的多元数学发生'
AUTHOR='王德生'
PARTS={1:'第一编　AI冲击与数学家的生涯转折',6:'第二编　工具革命与新行业涌现的历史',11:'第三编　从职业替代到新研究阵地的发生',16:'第四编　从库恩的常规科学到数学典范多元化',21:'第五编　SDE视野中的多元数学发生',26:'第六编　人—AI典范实验室：发明新的数模型',31:'第七编　数学生涯、教育与共同体的升级'}
DESCRIPTION='工具是技术、能力与智慧的封装。当解题与证明进入工具，数学家怎样在人—AI复合体中展开新的对象、模型与典范？王德生从工具史、SDE数学发生与伞模型实验室出发，提出能够实践、检验和继续修正的研究纲领。'
e=html.escape

def write(rel,text):
    p=DEST/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text,encoding='utf-8')

def convert(md,prefix=''):
    args=['pandoc','--from=markdown+tex_math_dollars+tex_math_single_backslash+autolink_bare_uris','--to=html5','--mathml','--wrap=none']
    if prefix:args+=['--id-prefix='+prefix]
    return subprocess.run(args,input=md,text=True,check=True,capture_output=True).stdout

def head(title,rel='',description=DESCRIPTION):
    return f'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{e(title)} | SDE Universes</title><meta name="description" content="{e(description,quote=True)}"><meta name="author" content="王德生"><link rel="canonical" href="{URL+rel}"><meta property="og:type" content="book"><meta property="og:title" content="{e(title,quote=True)}"><meta property="og:description" content="{e(description,quote=True)}"><meta property="og:image" content="{URL}assets/cover.png"><link rel="stylesheet" href="{BASE}assets/book.css"><script src="{BASE}assets/book.js" defer></script></head><body id="top"><a class="skip" href="#main">跳至正文</a>'''

def bar():
    return f'''<header class="sitebar"><div class="barinner"><a class="brand" href="/">SDE UNIVERSES<small>DEMAI INTERNATIONAL PRESS</small></a><nav class="toplinks" aria-label="书籍导航"><a href="/books/">全部图书</a><a href="{BASE}">本书首页</a><a href="{BASE}chapters.html">章节目录</a><a href="{BASE}read.html">在线翻页</a></nav></div></header>'''

def footer():
    return f'''<footer class="bookfooter"><div>王德生 著 · 数字阅读版 v1.0<br>德麦国际出版社 · Demai International Press</div><div><a href="{BASE}#downloads">下载与配套资料</a> · <a href="{BASE}text/#publication">出版与版本说明</a><br>© 2026 王德生 · SDE Universes</div></footer><a class="backtop" href="#top" aria-label="回到页首">↑ 页首</a></body></html>'''

def chapter_url(i):return BASE+f'text/chapter-{i:02}.html'

def groups(chapters,pages,full=False):
    buf=[]
    for name,ids in [('导论',[0])]+[(n,list(range(i,i+5))) for i,n in PARTS.items()]+[('结语与附录',[36,37,38])]:
        buf.append('<section class="partgroup"><h3>'+e(name)+'</h3><ol class="chapter-list">')
        for i in ids:
            c=chapters[i];href=BASE+'text/#chapter-'+f'{i:02}' if full else chapter_url(i)
            number=f'{i:02}' if 1<=i<=35 else {0:'序',36:'终',37:'附一',38:'附二'}[i]
            title=re.sub(r'^(第[一二三四五六七八九十]+章|导论|结语|附录[一二])\s*','',c['title'])
            page=f'<span class="page">PDF {pages[str(i)]} 页</span>' if str(i) in pages else ''
            buf.append(f'<li><a href="{href}"><span class="chapnum">{number}</span><span class="chaptitle">{e(title)}</span>{page}</a></li>')
        buf.append('</ol></section>')
    return ''.join(buf)

def sidebar(chapters,pages):
    supplements='<p class="note"><a href="'+BASE+'text/#publication">出版说明</a> · <a href="'+BASE+'text/#front-preface">前言</a> · <a href="'+BASE+'text/#front-reader_guide">导读</a><br><a href="'+BASE+'text/#references">参考文献</a> · <a href="'+BASE+'text/#subject-index">主题索引</a></p>'
    return '<aside class="tocside"><details open><summary>全书目录</summary><input data-toc-filter type="search" aria-label="筛选章节标题" placeholder="查找章节…">'+supplements+groups(chapters,pages,True)+'</details></aside>'

def reading_bar():
    return f'''<div class="progress" aria-hidden="true"></div><nav class="readerbar" aria-label="阅读设置"><div class="barinner"><a class="crumb" href="{BASE}">{TITLE}</a><div class="readercontrols"><button data-font="-1" aria-label="减小正文字号">A−</button><button data-font="1" aria-label="增大正文字号">A＋</button><button data-theme aria-label="切换阅读纸色">纸色</button><a class="button" href="{BASE}chapters.html" style="padding:4px 8px;font-size:12px">目录</a></div></div></nav>'''

def frontmatter():
    # Explicit selections avoid accidentally publishing internal reports.
    candidates=['author.md','preface.md','reader_guide.md','web_frontmatter.md']
    pieces=[]
    for name in candidates:
        p=BOOK/'frontmatter'/name
        if p.exists():pieces.append('<section id="front-'+p.stem+'">'+convert(p.read_text(),'front-'+p.stem+'-')+'</section>')
    return ''.join(pieces)

def bibliography():
    # Share the document parser without running document layout code.
    tree=ast.parse((BOOK/'build_book.py').read_text())
    function=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='bibliography_entries')
    module=ast.Module(body=[function],type_ignores=[])
    env={'ROOT':BOOK,'QA':HERE,'json':json,'re':re}
    exec(compile(module,'shared-bibliography-parser','exec'),env)
    entries=env['bibliography_entries']()
    (HERE/'bibliography.entries.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2))
    return convert('\n\n'.join(f'[{i+1}] {x}' for i,x in enumerate(entries)),'ref-')

def subject_index():
    tree=ast.parse((BOOK/'finalize_navigation.py').read_text())
    assignment=next((n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='topics' for t in n.targets)),None)
    if assignment is None:return ''
    topics=ast.literal_eval(assignment.value)
    rows=''.join('<tr><td>'+e(topic)+'</td><td>'+ ' · '.join(f'<a href="{chapter_url(i)}">'+({0:'导论',36:'结语',37:'附录一',38:'附录二'}.get(i,f'第{i}章'))+'</a>' for i in ids)+'</td></tr>' for topic,ids in topics.items())
    return '<section class="chapterblock" id="subject-index"><h2 class="chaptertitle">主题索引</h2><table><thead><tr><th>主题</th><th>相关章节</th></tr></thead><tbody>'+rows+'</tbody></table></section>'

def make_reader(chapters,pages):
    reader=(HERE/'reference/reader302.html').read_text()
    reader=reader.replace('AI时代死亡的困境和出路',TITLE).replace('数字永生之后，谁来接那个空位',SUBTITLE).replace('/books/m/302/',BASE)
    # Physical PDF page numbers are used throughout: no invented printed-page offset.
    cfg={'pdf':BASE+'assets/mathematicians-future-reading.pdf','key':'mathematicians-future-v1','offset':1}
    toc=[{'t':'封面','p':'1','g':1,'l':1}]
    toc += [{'t':c['title'],'p':str(pages[str(i)]),'g':pages[str(i)],'l':1} for i,c in chapters.items() if str(i) in pages]
    # Final PDF bookmarks also cover front matter, parts, references and index.
    pdf_path=DEST/'assets/mathematicians-future-reading.pdf'
    if pdf_path.exists():
        import fitz
        with fitz.open(pdf_path) as pdf:
            actual=pdf.get_toc()
            if actual:toc=[{'t':'封面','p':'1','g':1,'l':1}]+[{'t':title,'p':str(page),'g':page,'l':min(level,2)} for level,title,page in actual if page>0]
    else:
        navigation=BOOK/'qa/book_navigation.json'
        if navigation.exists():
            for item in json.loads(navigation.read_text()):
                i=str(item.get('index',''))
                if i in pages and not any(t['t']==item['title'] for t in toc):toc.append({'t':item['title'],'p':str(pages[i]),'g':pages[i],'l':1})
            toc.sort(key=lambda x:x['g'])
    reader=re.sub(r'(<script type="application/json" id="cfg">).*?(</script>)',lambda m:m[1]+json.dumps(cfg,ensure_ascii=False)+m[2],reader,flags=re.S)
    reader=re.sub(r'(<script type="application/json" id="toc">).*?(</script>)',lambda m:m[1]+json.dumps(toc,ensure_ascii=False)+m[2],reader,flags=re.S)
    # Keep familiar PDF controls while offering an always available text alternative.
    reader=reader.replace('>详情</a>','>书页</a><a href="'+BASE+'text/" style="color:var(--dim);text-decoration:none;font-size:.82rem">全文</a>')
    reader=reader.replace('<span class="pg">第 ','<span class="pg" title="PDF物理页码">PDF 第 ')
    reader=reader.replace("cur = (saved>0&&saved<=total) ? saved : 1;", "var target=parseInt((location.hash.match(/p=(\\d+)/)||[])[1]||'0',10); cur = target>0&&target<=total ? target : ((saved>0&&saved<=total) ? saved : 1); window.addEventListener('hashchange',function(){var p=parseInt((location.hash.match(/p=(\\d+)/)||[])[1]||'0',10);if(p>0&&p<=total)go(p);});")
    reader=reader.replace('</head>','<style>@media(max-width:600px){.top{gap:.32rem;padding-left:.5rem;padding-right:.5rem}.top .ttl{max-width:calc(100vw - 235px)}.top button{padding:.25rem .4rem;font-size:.8rem}}</style></head>')
    assert 'chen-feng' not in reader and '/m/302' not in reader and 'books-m-302' not in reader
    write('read.html',reader)

def make_shelves(record):
    data=json.loads((HERE/'reference/catalog.base.json').read_text())
    old=[b for b in data['books'] if b['id']!=SLUG]
    data['books']=[record]+old;data['updated']=record['publishedAt'][:10]
    p=OUT/'books/catalog.json';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
    # The reference script's final subprocess calls inject agents site-wide.
    # Evaluate only definitions and the three existing shelf writes in a temp tree.
    source=(HERE/'reference/build_bookshelf.reference.py').read_text().split('# 书生入口同步到详情页')[0]
    assert 'subprocess.run' not in source
    with tempfile.TemporaryDirectory(prefix='math-book-shelves-') as td:
        root=Path(td);(root/'tools').mkdir();(root/'public/books').mkdir(parents=True)
        script=root/'tools/build_bookshelf.py';script.write_text(source)
        shutil.copy2(p,root/'public/books/catalog.json')
        shutil.copy2(HERE/'reference/agents.base.json',root/'public/books/agents.json')
        subprocess.run(['python3',str(script)],check=True)
        for name in ['books/index.html','monographs/index.html','sites/read/library/index.html']:
            target=OUT/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/'public'/name,target)
    assert [b for b in data['books'] if b['id']!=SLUG]==old

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--no-shelves',action='store_true');parser.add_argument('--published-at',help='Explicit first-publication UTC timestamp; defaults to this build time.');args=parser.parse_args()
    DEST.mkdir(parents=True,exist_ok=True);(DEST/'assets').mkdir(exist_ok=True)
    for name in ['book.css','book.js']:shutil.copy2(HERE/name,DEST/'assets'/name)
    for name in ['figure26_1.png','figure26_2.png']:
        p=BOOK/'figures'/name
        if p.exists():shutil.copy2(p,DEST/'assets'/name)
    cover=BOOK/'figures/cover.png'
    if cover.exists():shutil.copy2(cover,DEST/'assets/cover.png')
    pp=BOOK/'qa/verified_page_map.json';pages=json.loads(pp.read_text()) if pp.exists() else {}
    pages={str(k):int(v) for k,v in pages.items()}
    chapters={}
    for i in range(39):
        p=BOOK/'chapters'/f'{i:02}.md';md=p.read_text();lines=md.splitlines()
        assert lines[0].startswith('# '),p
        title=lines[0][2:].strip();body='\n'.join(lines[1:]).strip()
        if i==26:
            body=body.replace('## 三、为什么必须区分三种同一性','![图26-1 有限记录位置上的单伞与双峰剖面。柱高严格对应正文算例；不表示连续位置上的实测结果。]('+BASE+'assets/figure26_1.png)\n\n## 三、为什么必须区分三种同一性')
            body=body.replace('## 六、让候选模型与既有理论正面相遇','![图26-2 衰减系数为二分之一时，两种输入次序得到相同总量、不同空间分布。]('+BASE+'assets/figure26_2.png)\n\n## 六、让候选模型与既有理论正面相遇')
        chapters[i]={'title':title,'body':body,'html':convert(body,f'c{i:02}-'),'sha256':hashlib.sha256(md.encode()).hexdigest()}
    toc=groups(chapters,pages)
    downloads=f'''<section class="section" id="downloads"><h2>把研究带回自己的工作台</h2><p class="intro">阅读、编辑、打印与复现，提供同一部书的不同入口。</p><div class="download-grid"><a class="download" href="{BASE}assets/mathematicians-future-reading.pdf" download><strong>阅读版 PDF ↗</strong><span>190 × 250 mm · 保留文字、公式与目录跳转</span></a><a class="download" href="{BASE}assets/mathematicians-future-print.pdf" download><strong>印刷版 PDF ↗</strong><span>170 × 240 mm · 适合纸面阅读</span></a><a class="download" href="{BASE}assets/mathematicians-future.docx" download><strong>可编辑 Word ↗</strong><span>完整正文与原生数学公式</span></a><a class="download" href="{BASE}assets/mathematicians-future-sources.zip" download><strong>源码与复现资料 ↗</strong><span>章节源文件、伞模型代码、测试与参考资料</span></a></div></section>'''
    hero=f'''<main id="main"><section class="hero"><div class="wrap hero-inner"><div class="hero-copy"><div class="eyebrow">数学 · AI · 研究的未来</div><h1>面对AI的冲击，<br>数学家走向何处？</h1><p class="subtitle">{SUBTITLE}</p><p class="author">王德生 著</p><p class="lead">工具是技术、能力与智慧的封装。<br>封装之后，我们能让怎样的新数学发生？</p><div class="buttons"><a class="button primary" href="{BASE}read.html">打开翻页阅读 →</a><a class="button secondary" href="{BASE}text/">阅读全文</a><a class="button secondary" href="{BASE}chapters.html">查看目录</a></div><a class="resume" data-resume style="color:#d9caa4" href="{BASE}text/">继续阅读</a></div><div class="hero-cover"><img class="cover" src="{BASE}assets/cover.png" alt="《{TITLE}》封面" width="380" height="500"></div></div></section><div class="wrap facts"><div class="fact"><strong>七编</strong>历史、理论与实践</div><div class="fact"><strong>三十五章</strong>展开数学家的未来</div><div class="fact"><strong>两篇附录</strong>科学与理念的多元发生</div><div class="fact"><strong>v1.0</strong>完整数字阅读版</div></div><div class="wrap"><section class="section"><div class="eyebrow">本书的问题</div><h2>当一道难题不再安顿一段生涯</h2><p class="intro">当AI不断扩展既定数学典范内的求解与证明能力，数学家需要重新组织研究生涯。常规研究继续提供证明、计算、反例与理论积累；在人—AI复合体中，多种对象、运算、结构和应用方向得到提出、展开、检验与发展。</p><blockquote class="pullquote">工具封装已有能力，也让领域面临新的选择：打开新的活动空间，或在相似成果之间加剧竞争。</blockquote><div class="three"><article class="panel"><span class="number">01</span><h3>从历史看职业重组</h3><p>印刷、纺织、铁路、汽车、电气化、制冷、集装箱与计算机：新活动怎样成立，从业者又如何转型？</p></article><article class="panel"><span class="number">02</span><h3>让典范猜想得到展开</h3><p>从库恩的常规科学进入SDE的数学发生，区分模型创新、研究纲领与形成中的典范。</p></article><article class="panel"><span class="number">03</span><h3>完成可接续的研究</h3><p>以伞模型贯通定义、运算、反例、证明与代码，把想法做成他人能够检验和继续的研究作品。</p></article></div></section><section class="section"><div class="eyebrow">阅读路径</div><h2>沿着问题进入，也可以从头读起</h2><div class="three"><article class="panel"><h3>关注自己的研究生涯</h3><p>从第一编进入，再读第七编，连接研究方向、职业条件与教育评价。</p><a href="{chapter_url(1)}">从第一章开始 →</a></article><article class="panel"><h3>关注理论与数学发生</h3><p>从第四、第五编进入，理解多元典范、SDE以及对象同一性的形成。</p><a href="{chapter_url(16)}">进入典范讨论 →</a></article><article class="panel"><h3>希望亲自运行一个模型</h3><p>从第六编进入，跟随一次允许失败、分化和修订的数学实验。</p><a href="{chapter_url(26)}">进入典范实验室 →</a></article></div></section>{downloads}<section class="section"><h2>完整目录</h2>{toc}<p class="note">数字阅读版 v1.0。出版与协作方式见<a href="{BASE}text/#publication">版本说明</a>。</p></section></div></main>'''
    write('index.html',head(TITLE)+bar()+hero+footer())
    write('chapters.html',head('章节目录 · '+TITLE,'chapters.html')+bar()+f'<main class="wrap" id="main"><header class="pagehead"><div class="eyebrow">全书目录</div><h1>{TITLE}</h1><p>{SUBTITLE}。导论、七编三十五章、结语与两篇附录。</p><div class="buttons"><a class="button primary" href="{BASE}text/">连续阅读全文</a><a class="button" href="{BASE}read.html">PDF在线翻页</a></div></header>'+toc+'</main>'+footer())
    side=sidebar(chapters,pages)
    full=[]
    pub=(BOOK/'frontmatter/publication.md').read_text()
    full.append('<section class="chapterblock" id="publication">'+convert(pub,'publication-')+'</section>')
    fm=frontmatter()
    if fm:full.append('<section class="chapterblock" id="frontmatter">'+fm+'</section>')
    intros_path=BOOK/'frontmatter/part_intros.json'
    intros=json.loads(intros_path.read_text()) if intros_path.exists() else {}
    for i,c in chapters.items():
        part=PARTS.get(i,'')
        if part:
            full.append('<div class="partdivider">'+e(part)+'</div>')
            intro=intros.get(str(i),'')
            if isinstance(intro,dict):intro=intro.get('text') or intro.get('intro') or ''
            if intro:full.append('<section class="partintro">'+convert(str(intro),f'part-{i}-')+'</section>')
        pdf=f'<a href="{BASE}read.html#p={pages[str(i)]}">对应PDF页</a>' if str(i) in pages else ''
        full.append(f'<section class="chapterblock" id="chapter-{i:02}"><h2 class="chaptertitle">{e(c["title"])}</h2><div class="chapteractions"><a href="{chapter_url(i)}">单独阅读本章</a>{pdf}</div>{c["html"]}</section>')
        prev=f'<a href="{chapter_url(i-1)}"><small>← 上一章</small>{e(chapters[i-1]["title"])}</a>' if i else '<span></span>'
        nxt=f'<a href="{chapter_url(i+1)}"><small>下一章 →</small>{e(chapters[i+1]["title"])}</a>' if i<38 else '<span></span>'
        inner=f'<main id="main" class="readinglayout">{side}<article class="readingpaper"><header><div class="eyebrow">{e(part or "数字阅读版 v1.0")}</div><h1>{e(c["title"])}</h1><div class="chapteractions"><a href="{BASE}text/#chapter-{i:02}">在全书中阅读</a>{pdf}</div></header><div class="prose">{c["html"]}</div><nav class="prevnext" aria-label="相邻章节">{prev}{nxt}</nav></article></main>'
        write(f'text/chapter-{i:02}.html',head(c['title']+' · '+TITLE,f'text/chapter-{i:02}.html')+reading_bar()+inner+footer())
    full.append('<section class="chapterblock" id="references"><h2 class="chaptertitle">参考文献与资料</h2>'+bibliography()+'</section>')
    full.append(subject_index())
    inner=f'<main class="readinglayout" id="main">{side}<article class="readingpaper"><header><div class="eyebrow">完整连续阅读</div><h1>{TITLE}</h1><p>{SUBTITLE}</p><p class="note">王德生 著 · 字号与纸色可在上方调整，阅读位置保存在本机浏览器。</p></header><div class="prose">'+''.join(full)+'</div></article></main>'
    write('text/index.html',head('全文阅读 · '+TITLE,'text/')+reading_bar()+inner+footer())
    make_reader(chapters,pages)
    published=args.published_at or datetime.datetime.now(datetime.timezone.utc).replace(microsecond=0).isoformat().replace('+00:00','Z')
    record={'id':SLUG,'number':None,'title':TITLE,'subtitle':SUBTITLE,'authors':[AUTHOR],'category':'math','description':DESCRIPTION,'detailUrl':URL,'readMode':'full','readLabel':'在线翻页阅读','readUrl':URL+'read.html','flipUrl':URL+'read.html','chapterUrl':URL+'chapters.html','textUrl':URL+'text/','pdfUrl':URL+'assets/mathematicians-future-reading.pdf','coverUrl':URL+'assets/cover.png','edition':'数字阅读版 v1.0','publishedAt':published}
    if not args.no_shelves:make_shelves(record)
    report={'generatedAt':published,'chapters':len(chapters),'pageMapEntries':len(pages),'mathML':sum(c['html'].count('<math') for c in chapters.values()),'sources':{str(i):{'title':c['title'],'sha256':c['sha256']} for i,c in chapters.items()},'newBookRecord':record}
    (HERE/'build-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:report[k] for k in ['chapters','pageMapEntries','mathML']},ensure_ascii=False))

if __name__=='__main__':main()
