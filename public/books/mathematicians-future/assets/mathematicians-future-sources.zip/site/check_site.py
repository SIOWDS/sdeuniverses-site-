#!/usr/bin/env python3
"""Static, source-complete checks; use strict mode after final assets arrive."""
from pathlib import Path
import argparse, hashlib, html, json, re, subprocess, tempfile, zipfile
from urllib.parse import urlparse,unquote
from bs4 import BeautifulSoup

HERE=Path(__file__).resolve().parent;BOOK=HERE.parent;OUT=HERE/'public'
BASE='/books/mathematicians-future/';DEST=OUT/BASE.lstrip('/')
def han(s):return ''.join(re.findall(r'[\u3400-\u9fff]',s))

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--allow-pending-downloads',action='store_true');args=parser.parse_args()
    errors=[];pending=[];checked=0;paragraphs=0
    report=json.loads((HERE/'build-report.json').read_text())
    docs={p:BeautifulSoup(p.read_text(),'html.parser') for p in DEST.rglob('*.html')}
    full=docs[DEST/'text/index.html']
    assert len(list((DEST/'text').glob('chapter-*.html')))==39
    for i in range(39):
        md=(BOOK/'chapters'/f'{i:02}.md').read_text();rec=report['sources'][str(i)]
        if hashlib.sha256(md.encode()).hexdigest()!=rec['sha256']:errors.append(f'stale chapter {i}')
        doc=docs[DEST/f'text/chapter-{i:02}.html']
        if doc.h1.get_text().strip()!=md.splitlines()[0][2:].strip():errors.append(f'wrong chapter title {i}')
        body=doc.select_one('.prose');block=full.find(id=f'chapter-{i:02}')
        for ti,table in enumerate(body.select('table')):
            rows=table.select('tr')
            width=len(rows[0].find_all(['th','td'],recursive=False)) if rows else 0
            for ri,row in enumerate(rows):
                cells=row.find_all(['th','td'],recursive=False)
                if len(cells)!=width:errors.append(f'chapter {i} table {ti} row {ri} wrong column count')
                if any(not c.get_text().strip() for c in cells):errors.append(f'chapter {i} table {ti} row {ri} empty cell (possible misplaced math/table delimiter)')
        for node in body.select('annotation'):node.decompose()
        body_han=han(body.get_text());full_han=han(block.get_text())
        for para in re.split(r'\n\s*\n','\n'.join(md.splitlines()[1:])):
            h=han(para)
            if len(h)<18:continue
            paragraphs+=1
            if h not in body_han:errors.append(f'chapter {i} missing passage: {h[:28]}')
            if h not in full_han:errors.append(f'full text chapter {i} missing passage: {h[:28]}')
    external=[]
    for path,doc in docs.items():
        if not doc.title or not doc.title.get_text().strip():errors.append(f'missing title {path}')
        ids=[x['id'] for x in doc.select('[id]')]
        if len(ids)!=len(set(ids)):errors.append(f'duplicate ids {path}')
        for tag in doc.find_all(['a','link','script','img']):
            value=tag.get('href') or tag.get('src')
            if not value:continue
            u=urlparse(value)
            if u.scheme and u.netloc not in ['sdeuniverses.com']:external.append(value);continue
            if u.path.startswith(BASE):
                target=OUT/unquote(u.path).lstrip('/')
            elif not u.path:
                target=path
            else:continue
            if u.path.endswith('/'):target=target/'index.html'
            checked+=1
            if not target.exists():
                pending.append(str(target.relative_to(OUT)));continue
            if u.fragment and target.suffix=='.html' and not u.fragment.startswith('p='):
                target_doc=docs.get(target)
                if target_doc is None:target_doc=BeautifulSoup(target.read_text(),'html.parser')
                if target_doc.find(id=unquote(u.fragment)) is None:errors.append(f'broken anchor {value}')
    urls=set(re.findall(r'https?://[^\s）<>]+','\n'.join(json.loads((HERE/'bibliography.entries.json').read_text()))))
    hrefs={a.get('href') for a in full.select('#references a')}
    missing=[]
    for url in urls:
        url=url.rstrip('.,。；;')
        if url not in hrefs:missing.append(url)
    if missing:errors.extend('bibliography link absent: '+u for u in missing)
    base=json.loads((HERE/'reference/catalog.base.json').read_text())
    cat=json.loads((OUT/'books/catalog.json').read_text())
    old=[b for b in base['books'] if b['id']!='mathematicians-future']
    new=[b for b in cat['books'] if b['id']!='mathematicians-future']
    if old!=new:errors.append('existing catalog records changed')
    own=[b for b in cat['books'] if b['id']=='mathematicians-future']
    if len(own)!=1:errors.append('new catalog identity not unique')
    elif any(own[0].get(k) for k in ['number','isbn','price']):errors.append('invented publication metadata')
    for rel in ['books/index.html','monographs/index.html','sites/read/library/index.html']:
        text=(OUT/rel).read_text()
        if text.count('data-id="mathematicians-future"')!=1:errors.append('wrong shelf entry count '+rel)
        card=BeautifulSoup(text,'html.parser').select_one('[data-id="mathematicians-future"]')
        if card and own and card.get('data-online')!=own[0]['publishedAt']:errors.append('shelf publication timestamp mismatch '+rel)
    reader=docs[DEST/'read.html'];cfg=json.loads(reader.find(id='cfg').string);toc=json.loads(reader.find(id='toc').string)
    if cfg['pdf']!=BASE+'assets/mathematicians-future-reading.pdf':errors.append('wrong PDF configuration')
    if cfg['key']!='mathematicians-future-v1':errors.append('wrong reading state key')
    raw=(DEST/'read.html').read_text()
    pdf_path=DEST/'assets/mathematicians-future-reading.pdf'
    page_file=BOOK/'qa/verified_page_map.json'
    if pdf_path.exists():
        import fitz
        with fitz.open(pdf_path) as pdf:
            print_pdf=DEST/'assets/mathematicians-future-print.pdf'
            if print_pdf.exists():
                with fitz.open(print_pdf) as printed:
                    if printed.page_count!=pdf.page_count:errors.append('reading/print PDF page counts differ')
            if any(not (1<=t['g']<=pdf.page_count) for t in toc):errors.append('reader TOC page out of bounds')
            if len(toc)<40:errors.append('reader TOC is missing book sections')
            if page_file.exists():
                pages=json.loads(page_file.read_text())
                for i in range(39):
                    title=report['sources'][str(i)]['title']
                    normalize=lambda s:re.sub(r'\s+','',s)
                    if not any(normalize(t['t'])==normalize(title) and t['g']==pages.get(str(i)) for t in toc):errors.append(f'reader TOC mismatch chapter {i}')
            else:errors.append('verified page map missing')
    for name in ['mathematicians-future.docx','mathematicians-future-sources.zip']:
        archive=DEST/'assets'/name
        if archive.exists():
            try:
                with zipfile.ZipFile(archive) as z:
                    corrupt=z.testzip()
                    if corrupt:errors.append(name+' has a corrupt member: '+corrupt)
                    names=z.namelist()
                    if name.endswith('.docx') and 'word/document.xml' not in names:errors.append('Word archive has no document')
                    if name.endswith('-sources.zip') and not any(n.endswith('umbrella_model.py') for n in names):errors.append('source archive has no umbrella model code')
            except zipfile.BadZipFile:errors.append(name+' is not a valid ZIP container')
    for old in ['chen-feng','books-m-302','/books/m/302/','AI时代死亡的困境和出路','9798906906403']:
        if old in raw:errors.append('old reader metadata '+old)
    for req in ['fontExtraProperties:true','isOffscreenCanvasSupported:false','SVGGraphics','p=(\\d+)']:
        if req not in raw:errors.append('missing reader capability '+req)
    with tempfile.TemporaryDirectory(prefix='book-reader-check-') as td:
        for i,tag in enumerate(reader.find_all('script')):
            if tag.get('src') or tag.get('type')=='application/json':continue
            p=Path(td)/f'inline-{i}.js';p.write_text(tag.string or tag.get_text())
            r=subprocess.run(['node','--check',str(p)],capture_output=True,text=True)
            if r.returncode:errors.append(r.stderr)
        r=subprocess.run(['node','--check',str(DEST/'assets/book.js')],capture_output=True,text=True)
        if r.returncode:errors.append(r.stderr)
    whitelist=[]
    for p in sorted(OUT.rglob('*')):
        if not p.is_file():continue
        rel=p.relative_to(OUT).as_posix()
        if not (rel.startswith(BASE.lstrip('/')) or rel in ['books/catalog.json','books/index.html','monographs/index.html','sites/read/library/index.html']):errors.append('out-of-scope file '+rel)
        whitelist.append({'path':'public/'+rel,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
    pending=sorted(set(pending))
    final={'htmlPages':len(docs),'chapters':39,'paragraphsChecked':paragraphs,'internalReferencesChecked':checked,'bibliographyURLs':len(urls),'mathML':report['mathML'],'readerTOCEntries':len(toc),'pendingAssets':pending,'errors':errors,'browserRenderVerified':False,'browserLimit':'Managed Sites runtime has no control-browser capability; no browser preview was improvised.'}
    (HERE/'qa-report.json').write_text(json.dumps(final,ensure_ascii=False,indent=2)+'\n')
    (HERE/'publish-manifest.json').write_text(json.dumps(whitelist,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(final,ensure_ascii=False,indent=2))
    if errors or (pending and not args.allow_pending_downloads):raise SystemExit(1)

if __name__=='__main__':main()
