# 新书网站构建与交接

独立新书 `/books/mathematicians-future/`，沿用站点现有部署。本站点候选输出不含第220、302号的任何文件，且不改工作流、不运行agent注入、不触发索引。

## 输出

`public/` 下路径与 GitHub 仓库完全对应，仅包含新书目录、书目JSON和三书架。`publish-manifest.json` 列出本次可提交的文件、大小与SHA256。主代理应仅提交该白名单，不提交整个旧站副本，也不提交本目录的参考快照。

新书有43个HTML：书页、PDF翻页、章节目录、连续全文、39个独立章节。章节实时读取 `../chapters/00.md`—`38.md`；版前文读取 `../frontmatter/`；图26-1/26-2随正文；书目调用与纸书相同的解析函数；主题索引复用纸书的topics映射。公式由Pandoc转成355个MathML（当前正文版本）。

## 最终构建顺序

1. 把最终阅读PDF、印刷PDF、Word和源码ZIP按约定名称放入 `public/books/mathematicians-future/assets/`。这四个名称分别为 `mathematicians-future-reading.pdf`、`mathematicians-future-print.pdf`、`mathematicians-future.docx`、`mathematicians-future-sources.zip`。
2. 最终完整封面位于 `../figures/cover.png`，脚本会自动复制；不会使用纯背景的 `cover-art.png`。最终页码写入 `../qa/verified_page_map.json`。
3. 提交前刷新 `reference/catalog.base.json` 和 `reference/agents.base.json` 为最新main，以保留并发上架的图书及现有书生名称。如现有书架生成器有新改动，同步 `reference/build_bookshelf.reference.py`；本地程序仅执行三书架输出，明确截掉结尾广域注入。
4. 运行 `python book/site/build_site.py`。最终PDF已经在assets时，直接从其真实书签构建翻页目录，包含前言、导读、七编、章节、书目与主题索引；章页跳转使用验证后的物理页码。
   新书 `publishedAt` 默认采用本次构建实际UTC时间，并统一生成三书架 `data-online`；不再保留首轮试构建时间。如需固定一次已确认的首次上线时间，传入 `--published-at 真实UTC时间`。
5. 运行 `python book/site/check_site.py`。正式交付必须无 `--allow-pending-downloads`，并且 `pendingAssets` 与 `errors` 都为空。当前只在待最终资产阶段使用该宽容参数。
6. 根代理读取最新main的tree和commit，在一个GitData提交中写入白名单全部文件；非强制更新main。同步既有Cloudflare Git集成后做线上验收。

## 已完成的静态校验

逐章标题/源文件SHA256、1709段正文、连续全文39个锚点、全文与章页链接、116个书目原URL、MathML数、JavaScript语法、PDF配置及目录、三书架新增条数、既有书目记录完全不变、没有旧书名/ISBN/PDF残留、提交白名单边界。具体结果见 `qa-report.json`。

阅读交互包括字号、纸色、本机进度、章节过滤、前后章、PDF页码深链接、连续全文的索引与导航。PDF页面沿用实际302阅读器的SVG主渲染和逐页位图回退；只保留站点已有的通用WDS脚本，没有新书专属智能体或音频承诺。

## 视觉核验限制

当前执行环境为managed Sites，工具未提供control-browser。遵循Sites技能，未另装浏览器或自行绕开预览路径。这里的通过仅指来源、结构、链接和代码静态验证，不冒称浏览器渲染通过。正式发布后需确认首屏封面、手机宽度、公式、PDF已载入及矢量指示；第220、302号原页面无须修改。
