# 第五编引用文献

1. 王德生：《点亮数学之灯：特征纠缠》，原载公众号“三二一智慧”，2025年9月9日；SDE Universes《特征纠缠解码》文章精选。https://sdeuniverses.com/books/m/5/articles/01/
2. SDE Universes：《知识是SIO的模型》，网页未核定原始发表年月。https://comp.sdeuniverses.com/thought/essays/sio-9486a25c33/
3. SDE Universes：《总览长卷：一页看完全站》，九宫总览页面，网页未核定原始发表年月。https://sdeuniverses.com/overview/
4. Dedekind, Richard. Stetigkeit und irrationale Zahlen, 1872; Was sind und was sollen die Zahlen?, 1888. English translation by Wooster Woodruff Beman, Essays on the Theory of Numbers. Chicago: Open Court, 1901. https://www.gutenberg.org/files/21016/21016-pdf.pdf
5. Newton, Isaac. Philosophiae Naturalis Principia Mathematica, 1726 edition, “Definitiones.” The Newton Project, University of Oxford, normalized transcription. https://www.newtonproject.ox.ac.uk/view/texts/normalized/NATP00085
6. Riemann, Bernhard. “Ueber die Hypothesen, welche der Geometrie zu Grunde liegen.” Lecture delivered 1854, published 1867. English translation by William Kingdon Clifford, “On the Hypotheses which lie at the Bases of Geometry,” Nature, vol. 8, pp. 14–17, 36–37. Trinity College Dublin transcription. https://www.maths.tcd.ie/pub/HistMath/People/Riemann/Geom/WKCGeom.html
7. Hamilton, William Rowan. “On Quaternions; or on a New System of Imaginaries in Algebra,” including the letter to John T. Graves dated October 17, 1843. Philosophical Magazine, vol. 25, 1844, pp. 489–495. Trinity College Dublin transcription. https://www.maths.tcd.ie/pub/HistMath/People/Hamilton/QLetter/QLetter.html
8. Euler, Leonhard. “Solutio problematis ad geometriam situs pertinentis.” Commentarii academiae scientiarum Petropolitanae, vol. 8, pp. 128–140; published 1741, Eneström E53. Euler Archive, University of the Pacific. https://scholarlycommons.pacific.edu/euler-works/53/
9. Eilenberg, Samuel, and Saunders Mac Lane. “General Theory of Natural Equivalences.” Transactions of the American Mathematical Society, vol. 58, 1945, pp. 231–294. DOI: 10.1090/S0002-9947-1945-0013131-6. https://zenodo.org/records/3928610
