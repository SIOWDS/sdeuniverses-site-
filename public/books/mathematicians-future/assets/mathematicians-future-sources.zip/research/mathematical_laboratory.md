# 第六编：数学与来源核验记录

本编为作者为本书设计的教学性、研究性最小构造；所有实验是合成算例，不声称人体触觉实验或既有成果的新颖性认证。基本数学命题在正文独立证明，代码验证仅检查算例和实现。

## 核心定义

有限度量空间 X；伞事件 p=(c,r,a)，c∈X、r≥0、a≥0。r>0 时 κ_p(x)=a max(0,1−d(x,c)/r)，r=0 时 κ_p=a1_{c}。一般状态 u∈R₊^X。相同参数、相同剖面、相同观测 Pu 三层分开。先用 T_v(u)=λu+v，再用 u'=Ku+v，K非负、最大行和≤ρ<1。线性观测商可闭合 iff kerP 对K不变，等价 PK=LP（L定义在imP并可扩张）。

## 核对来源

1. Zadeh, L. A. (1965). Fuzzy sets. Information and Control 8(3), 338–353. DOI: 10.1016/S0019-9958(65)90241-X. 原论文公开副本 https://home.iitk.ac.in/~avrs/ManyValuedLogic/Zadeh-1965.pdf ，期刊页 https://www.sciencedirect.com/science/article/pii/S001999586590241X 。2026-10-11核对：隶属函数取值[0,1]；不要把范围剖面本身说成前所未有。仅用于简短概念比较。
2. Muandet, K., Fukumizu, K., Sriperumbudur, B., & Schölkopf, B. (2017). Kernel Mean Embedding of Distributions: A Review and Beyond. Foundations and Trends in Machine Learning 10(1–2), 1–141. DOI: 10.1561/2200000060. 作者稿 https://arxiv.org/abs/1605.09522 ，核对页显示2020年最终修订、2017年期刊记录。用于区分本书一般非负影响核与需要正定性条件的RKHS核均值嵌入；未证明本书任意度量上的帐篷核正定，绝不作此暗示。
3. Lee, E. A., & Seshia, S. A. Introduction to Embedded Systems: A Cyber-Physical Systems Approach. 作者官方页 https://ptolemy.berkeley.edu/books/leeseshia/download.html ，以及 Berkeley EE221A课程 https://www2.eecs.berkeley.edu/Courses/EE221A/ 。核对既有状态空间、可观测性、最小性研究存在。本书所有具体线性结论自行证明，不冒称原创控制理论。
4. Geiger, B. C., & Temmel, C. Lumpings of Markov chains, entropy rate preservation, and higher-order lumpability. 作者预印本 https://arxiv.org/abs/1212.4375 。仅记录相关检索近邻：投影可能失去原有演化闭合。正文不把本书确定性向量更新等同于该论文的随机链，也不据摘要延展其技术结论。

检索注意：一次system1组合搜索返回无关品牌页面，全部弃用。Stanford EE263两次直接打开返回工具不可访问，未用作读过的证据。

## 最终完成记录

- 正文章节：26=6049、27=6015、28=6019、29=6014、30=6020汉字；合计30117。统计排除所有Markdown标题，仅计U+3400—U+9FFF，不把代码、书目与研究记录算作正文。
- 核心代码：code/umbrella_model.py；测试code/test_umbrella_model.py；读者运行说明code/README.md。
- 11项测试实际运行通过；包括二维观察含输入闭合、稳定界网格检查、次序公式、传播支持、饱和与归一化反例、同维标准线性基线等价、总量重建误差下界算例。
- 原始运行输出：research/umbrella_results.json，使用精确Fraction分数。
- 公式：352处数学表达经Pandoc从Markdown解析为Math节点；逐章无字面美元符号遗留，公式大括号检查无不配对。最终Word/渲染由总编负责。
- 26—30章由第五编并行智能体交叉检查，反馈未发现阻断性数学问题；这属于同项目智能体复核，不是外部同行评议。
- 30章公平比较明确：伞线性分支与标准三维线性状态空间数学等价，同为零误差；总量1/16下界仅针对两条指定历史的当前左端强度重建。
- 30章补充两个完整初等证明：非局域非负生成器不能生成单点基向量；对所有非负行和收缩矩阵不存在非零非单射的统一闭合观察。
- 正式书末参考文献见research/bibliography_math.md；Markov lumping仅作近邻检索记录，未列入书末依据。

