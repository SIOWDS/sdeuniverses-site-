# 第六编参考文献

Zadeh, L. A. (1965). Fuzzy sets. *Information and Control*, 8(3), 338–353. https://doi.org/10.1016/S0019-9958(65)90241-X . 原文公开副本：https://home.iitk.ac.in/~avrs/ManyValuedLogic/Zadeh-1965.pdf 。

Muandet, K., Fukumizu, K., Sriperumbudur, B., & Schölkopf, B. (2017). Kernel Mean Embedding of Distributions: A Review and Beyond. *Foundations and Trends in Machine Learning*, 10(1–2), 1–141. https://doi.org/10.1561/2200000060 . 作者稿：https://arxiv.org/abs/1605.09522 。

Lee, E. A., & Seshia, S. A. (2017). *Introduction to Embedded Systems: A Cyber-Physical Systems Approach* (2nd ed.). MIT Press. ISBN 978-0-262-53381-2. 作者官方页面：https://ptolemy.berkeley.edu/books/leeseshia/ 。

以上来源用于本编的已有理论定位；本编具体命题以正文中的独立证明为依据。网页核对日期：2026年10月11日。
