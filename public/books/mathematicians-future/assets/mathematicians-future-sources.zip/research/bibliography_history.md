# 第二编参考文献

以下文献按对应章节排列。同一机构不同藏品或档案各列一项；网页未标示可靠出版年份时注明“未标年”。在线资料访问日期为2026年10月10日。

## 第六章

- H06-01. British Library, International Dunhuang Programme. Buddhist texts: The Diamond Sūtra[EB/OL]. 未标年. https://idp.bl.uk/discover/learning/buddhism-on-the-silk-roads/articles/buddhism-on-the-ground/buddhist-texts-the-diamond-sutra/
- H06-02. ChinaCulture. Celebrities in Printing and Paper-making History[EB/OL]. 2008-02-06. https://en.chinaculture.org/library/2008-02/06/content_46431.htm
- H06-03. Library of Congress. Gutenberg Bible[DB/OL]. 馆藏目录，印本约1454—1455年，目录网页未标年. https://www.loc.gov/item/2021666734/
- H06-04. Library of Congress. Introduction: The Gutenberg Bible at the Library of Congress: A Resource Guide[EB/OL]. 未标年. https://guides.loc.gov/gutenberg/introduction
- H06-05. Museum Plantin-Moretus. The printing workshop[EB/OL]. 未标年. https://museumplantinmoretus.be/en/seeing-doing/museum/printing-workshop
- H06-06. Museum Plantin-Moretus. The library[EB/OL]. 未标年. https://www.museumplantinmoretus.be/en/seeing-doing/museum/library
- H06-07. Dibbits, Kat. Richard Arkwright: innovation and controversy[EB/OL]. Science and Industry Museum, 2017-08-03. https://blog.scienceandindustrymuseum.org.uk/richard-arkwright/
- H06-08. The National Archives. Arkwright’s spinning frame[EB/OL]. Georgian Britain: Age of Modernity，未标年. https://www.nationalarchives.gov.uk/education/resources/georgian-britain-age-modernity/arkwrights-spinning-frame/
- H06-09. Elliott, Francesca. Jacquard loom[EB/OL]. Science and Industry Museum，未标年. https://blog.scienceandindustrymuseum.org.uk/jacquard-loom/
- H06-10. The National Archives. Why did the Luddites protest?[EB/OL]. 档案教学资料，未标年. https://www.nationalarchives.gov.uk/education/teaching-resources/why-did-the-luddites-protest/ ; PDF: https://cdn.nationalarchives.gov.uk/documents/why-did-the-luddites-protest.pdf
- H06-11. UK Parliament. Hand—Loom Weavers[Z/OL]. House of Commons Debates, 1835-07-28. https://hansard.parliament.uk/Commons/1835-07-28/debates/84f66c4a-7061-4e90-81d5-924ee2371301/Hand%C3%A2%E2%82%AC%E2%80%9DLoomWeavers

## 第七章

- H07-01. National Museums Scotland. The Newcomen engine and its role in Britain’s industrial revolution[EB/OL]. 未标年. https://www.nms.ac.uk/discover-catalogue/the-newcomen-engine-and-its-role-in-britains-industrial-revolution
- H07-02. Science Museum Group. Newcomen Atmospheric Engine[DB/OL]. 馆藏目录，未标年. https://collection.sciencemuseumgroup.org.uk/objects/co50900/newcomen-atmospheric-engine
- H07-03. Russell, Ben. James Watt and the separate condenser[EB/OL]. Science Museum, 2019-01-05. https://blog.sciencemuseum.org.uk/james-watt-and-the-separate-condenser/
- H07-04. Historic England. Soho Foundry Former Boulton and Watt Foundry Pattern Stores and Erecting Shops[DB/OL]. National Heritage List for England, List Entry 1268451. 1996年列入，1997年修订. https://historicengland.org.uk/listing/the-list/list-entry/1268451
- H07-05. Institution of Civil Engineers. History of ICE—Shaping Civil Engineering[EB/OL]. 未标年. https://ice.org.uk/about-us/our-organisation/history
- H07-06. Institution of Civil Engineers. ICE Archives[EB/OL]. 未标年. https://www.ice.org.uk/about-us/our-services/library/ice-archives
- H07-07. Rainhill Railway & Heritage Society. The 1829 Trials[EB/OL]. 未标年. https://www.rainhilltrials.org/the-1829-trials.html
- H07-08. Rainhill Railway & Heritage Society. The Trials—History[EB/OL]. 未标年. https://www.rainhilltrials.org/the-trials-history.html
- H07-09. Thorpe, Peter. Time detectives—discovering the history of railway clocks[EB/OL]. National Railway Museum, 2019，2023年更新. https://blog.railwaymuseum.org.uk/time-detectives-discovering-the-history-of-railway-clocks/
- H07-10. Science Museum Group. Clock dial marked ‘Potter, Railway Time’, 1840–1880[DB/OL]. 馆藏编号1978-208，目录网页未标年. https://collection.sciencemuseumgroup.org.uk/objects/co1016/clock-dial-marked-potter-railway-time-1840-1880
- H07-11. Science Museum Group. Signalling & Telecommunications on display in the Open Store at the National Railway Museum[DB/OL]. 馆藏目录，未标年. https://collection.sciencemuseumgroup.org.uk/search/categories/signalling-%26-telecommunications/museum/national-railway-museum/gallery/open-store
- H07-12. Shillam, Tom. Navvies: Caught on the wrong side of the track[EB/OL]. National Railway Museum, 2017. https://blog.railwaymuseum.org.uk/navvies-caught-wrong-side-track/
- H07-13. Esbester, Mike. Railway Workers After the Accident[EB/OL]. National Railway Museum, 2018-12-14. https://blog.railwaymuseum.org.uk/railway-workers-after-the-accident/
- H07-14. University of Portsmouth; National Railway Museum; Modern Records Centre, University of Warwick. The Accidents[DB/OL]. Railway Work, Life & Death，未标年. https://www.railwayaccidents.port.ac.uk/the-accidents/

## 第八章

- H08-01. Casey, Bob. Henry Ford: Case Study of an Innovator[EB/OL]. The Henry Ford，未标年. https://www.thehenryford.org/collections/explore/articles/henry-ford-case-study-of-an-innovator
- H08-02. The Henry Ford. Horse Drawn Dray, circa 1890[DB/OL]. 馆藏目录，未标年. https://www.thehenryford.org/collections/explore/artifact/219292
- H08-03. Federal Highway Administration. Foundations of Road Safety[EB/OL]. Road Safety Fundamentals, Unit 1，未标年. https://highways.fhwa.dot.gov/safety/learn-safety/road-safety-fundamentals-html-version/unit-1-foundations-road-safety
- H08-04. Federal Highway Administration. The Evolution of MUTCD[EB/OL]. 未标年. https://mutcd.fhwa.dot.gov/kno-history.htm
- H08-05. Federal Highway Administration. The National Old Trails Road[EB/OL]. 未标年. https://www.fhwa.dot.gov/infrastructure/not4.pdf
- H08-06. Federal Highway Administration. Moving the Goods: As the Interstate Era Begins[EB/OL]. 未标年. https://www.fhwa.dot.gov/infrastructure/freight.cfm
- H08-07. National Park Service. Edison Biography[EB/OL]. Thomas Edison National Historical Park，未标年. https://www.nps.gov/edis/learn/historyculture/edison-biography.htm
- H08-08. National Museum of American History. Lighting a Revolution: 19th Century Consequences[EB/OL]. Smithsonian Institution，未标年. https://americanhistory.si.edu/lighting/19thcent/consq19.htm
- H08-09. David, Paul A. The Dynamo and the Computer: An Historical Perspective on the Modern Productivity Paradox[J]. American Economic Review, 1990, 80(2):355–361. 书目信息：https://ideas.repec.org/a/aea/aecrev/v80y1990i2p355-61.html
- H08-10. David, Paul A. Computer and Dynamo: The Modern Productivity Paradox in a Not-Too Distant Mirror[R/OL]. University of Warwick, Warwick Economic Research Papers, No.339, 1989. https://ageconsearch.umn.edu/record/268373/files/twerp339.pdf
- H08-11. National Park Service. Rural Electrification Act[EB/OL]. Homestead National Historical Park, 2021-08-08更新. https://www.nps.gov/home/learn/historyculture/ruralelect.htm
- H08-12. National Park Service. Idaho: Minidoka Powerplant[EB/OL]. 未标年. https://www.nps.gov/articles/idaho-minidoka-powerplant.htm

## 第九章

- H09-01. National Park Service. Fresh Pond Ice Company Sign[DB/OL]. Longfellow House—Washington’s Headquarters National Historic Site, 2021-02-19更新. https://home.nps.gov/articles/000/fresh-pond-ice-company-sign.htm
- H09-02. National Museum of American History. Keeping your (food) cool: From ice harvesting to electric refrigeration[EB/OL]. Smithsonian Institution, 2015. https://americanhistory.si.edu/explore/stories/keeping-your-food-cool-ice-harvesting-electric-refrigeration
- H09-03. National Park Service. Nathaniel Wyeth[EB/OL]. 未标年. https://www.nps.gov/people/nathanielwyeth.htm
- H09-04. Reynolds, Maria. When Ice Came from the Hudson River: Ice Harvesting in Staatsburg[EB/OL]. New York State Parks, 2021-02-23. https://nystateparks.blog/2021/02/23/when-ice-came-from-the-hudson-river-ice-harvesting-in-staatsburg/
- H09-05. National Museum of American History. Before the refrigerator got its hum[EB/OL]. Object Project, Smithsonian Institution，未标年. https://www.americanhistory.si.edu/explore/exhibitions/object-project/online/refrigerators/ice-tongs
- H09-06. National Park Service. Barnyard Trail: Ice House[EB/OL]. 未标年. https://www.nps.gov/places/barnyard-trail-ice-house.htm
- H09-07. Deutsches Historisches Museum. Carl Linde (1842–1934)[EB/OL]. Gründerzeit展览人物资料，未标年. https://www.dhm.de/archiv/ausstellungen/gruenderzeit/biografien/linde_carl.html
- H09-08. National Museum of American History. Not just a cool convenience: How electric refrigeration shaped the “cold chain”[EB/OL]. Smithsonian Institution，未标年. https://www.americanhistory.si.edu/explore/stories/not-just-cool-convenience-how-electric-refrigeration-shaped-cold-chain
- H09-09. National Museum of American History. From the wok to the frozen food aisle[EB/OL]. Smithsonian Institution, 2015. https://americanhistory.si.edu/explore/stories/wok-frozen-food-aisle
- H09-10. National Museum of American History. A System for Abundance[EB/OL]. FOOD: Transforming the American Table, Smithsonian Institution，未标年. https://americanhistory.si.edu/explore/exhibitions/food/online/new-and-improved/system-abundance
- H09-11. International Longshore and Warehouse Union. Bill Ward: 65 Years with the ILWU[Z/OL]. ILWU Oral Histories Collection，网页未标年. https://archive.ilwu.org/ilwu-oral-histories-collection/longshore/bill-ward-65-years-with-the-ilwu/
- H09-12. Gerena, Charles. A Shipping Visionary[EB/OL]. Federal Reserve Bank of Richmond, Econ Focus, Winter 2005. https://www.richmondfed.org/publications/research/econ_focus/2005/winter/feature2_web_exclusive2
- H09-13. National Museum of American History. Transforming the Waterfront[EB/OL]. America on the Move, Smithsonian Institution，未标年. https://americanhistory.si.edu/explore/exhibitions/america-on-the-move/online/transforming-waterfront
- H09-14. International Organization for Standardization. ISO/TC 104: Freight containers[EB/OL]. 技术委员会资料，未标年. https://www.iso.org/committee/51156.html
- H09-15. International Organization for Standardization. Boxing clever—How standardization built a global economy[EB/OL]. 2017. https://www.iso.org/cms/%20render/live/en/sites/isoorg/contents/news/2017/09/Ref2215.html
- H09-16. International Longshore and Warehouse Union; Pacific Maritime Association. Mechanization and Modernization Agreement[Z/OL]. 1960-10-18. ILWU Local 19存档. https://www.ilwu19.com/history/mandm
- H09-17. International Longshore and Warehouse Union. The ILWU Story[EB/OL]. 未标年. https://www.ilwu.org/history/the-ilwu-story/

## 第十章

- H10-01. McLennan, Sarah; Gainer, Mary. When the Computer Wore a Skirt: Langley’s Computers, 1935–1970[EB/OL]. NASA History News and Notes, 2012,29(1)；NASA网页2016-11-25. https://www.nasa.gov/history/langleys-computers-1935-1970/
- H10-02. NASA. Dorothy J. Vaughan[EB/OL]. 2017-05-25. https://www.nasa.gov/centers-and-facilities/langley/dorothy-j-vaughan/
- H10-03. IEEE Computer Society. About Women of ENIAC[EB/OL]. 未标年. https://www.computer.org/volunteering/awards/pioneer/about-women-of-eniac
- H10-04. Computer History Museum. ENIAC[EB/OL]. Revolution: The First 2000 Years of Computing，未标年. https://www.computerhistory.org/revolution/birth-of-the-computer/4/78
- H10-05. McJones, Paul, ed. History of FORTRAN and FORTRAN II[DB/OL]. Computer History Museum, Software Preservation Group，持续更新资料集. https://softwarepreservation.computerhistory.org/FORTRAN/
- H10-06. Backus, John W., et al. The FORTRAN Automatic Coding System[C/OL]. Proceedings of the Western Joint Computer Conference, 1957. https://softwarepreservation.computerhistory.org/FORTRAN/paper/BackusEtAl-FortranAutomaticCodingSystem-1957.pdf
- H10-07. Computer History Museum. 1957: Timeline of Computer History[EB/OL]. 未标年. https://www.computerhistory.org/timeline/1957/
- H10-08. Hopper, Grace. Oral History of Captain Grace Hopper: Interviewed by Angeline Pantages[Z/OL]. 1980年12月访谈，附后续编者年表. Computer History Museum, Accession 102702026，Reference X5142.2009. https://archive.computerhistory.org/resources/access/text/2015/06/102702026-05-01-acc.pdf
- H10-09. NASA. Katherine G. Johnson[EB/OL]. 未标年. https://www.nasa.gov/people-of-nasa/katherine-g-johnson/
- H10-10. Naur, Peter; Randell, Brian, eds. Software Engineering: Report on a Conference Sponsored by the NATO Science Committee, Garmisch, Germany, 7th to 11th October 1968[R/OL]. Brussels: NATO Scientific Affairs Division, 1969. https://homepages.cs.ncl.ac.uk/brian.randell/NATO/nato1968.PDF
- H10-11. Grad, Burton. A personal recollection: IBM’s unbundling of software and services[J/OL]. IEEE Annals of the History of Computing, 2002. https://ieeexplore.ieee.org/document/988583
- H10-12. Leiner, Barry M.; Cerf, Vinton G.; Clark, David D.; Kahn, Robert E.; Kleinrock, Leonard; Lynch, Daniel C.; Postel, Jon; Roberts, Lawrence G.; Wolff, Stephen. A Brief History of the Internet[EB/OL]. Internet Society, 1997. https://www.internetsociety.org/internet/history-internet/brief-history-internet/
- H10-13. Internet Society. New Year’s Day Marks 30th Anniversary of Major Milestone for Global Internet[EB/OL]. 2013-01-01. https://www.internetsociety.org/news/press-releases/2013/new-years-day-marks-30th-anniversary-of-major-milestone-for-global-internet/
- H10-14. National Science Foundation. The Internet[EB/OL]. NSF 50th Anniversary History，2000. https://www.nsf.gov/about/history/nsf0050/pdf/internet.pdf
- H10-15. CERN. A short history of the Web[EB/OL]. 未标年. https://home.cern/science/computing/the-birth-of-the-web/short-history-web/
- H10-16. CERN. 30 years of a free and open Web[EB/OL]. 2023. https://home.web.cern.ch/news/news/computing/30-years-free-and-open-web
- H10-17. National Center for Supercomputing Applications. NCSA Mosaic[EB/OL]. University of Illinois Urbana-Champaign，未标年. https://www.ncsa.illinois.edu/research/project-highlights/ncsa-mosaic/
- H10-18. University of Illinois Urbana-Champaign. Mosaic[EB/OL]. Distributed Museum，未标年. https://distributedmuseum.illinois.edu/exhibit/mosaic/
