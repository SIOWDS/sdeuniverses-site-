# 第七编参考文献

1. University of Oxford, Mathematical Institute. Doctor of Philosophy (DPhil). 2026年4月16日更新. https://www.maths.ox.ac.uk/study-here/postgraduate-study/doctor-philosophy-dphil （访问日期：2026年10月11日）.
2. Lean FRO. Mathlib: A Foundation for Formal Mathematics Research and Verification. 无日期. https://lean-lang.org/use-cases/mathlib/ （访问日期：2026年10月11日）.
3. Lean Mathematical Library Community. Contributing to mathlib. 2026年现行版. https://leanprover-community.github.io/contribute/index.html （访问日期：2026年10月11日）.
4. Society for Industrial and Applied Mathematics. SIAM Report on Mathematics in Industry. Philadelphia: SIAM, 2012. ISBN 978-1-611972-37-5. https://www.siam.org/media/hmfk214f/mathematics_industry_2012.pdf .
5. Society for Industrial and Applied Mathematics. Career Resources. 无日期. https://www.siam.org/programs-initiatives/professional-development/career-resources/ （访问日期：2026年10月11日）.
6. University of Cambridge, Blended Learning Service. Generative AI and Assessment. 无日期. https://blendedlearning.cam.ac.uk/artificial-intelligence-and-education/generative-ai-and-assessment （访问日期：2026年10月11日）.
7. DORA. San Francisco Declaration on Research Assessment. 2013. https://sfdora.org/read/ .
8. Coalition for Advancing Research Assessment. Agreement on Reforming Research Assessment. 2022. https://www.coara.org/agreement/the-agreement-full-text/ .
