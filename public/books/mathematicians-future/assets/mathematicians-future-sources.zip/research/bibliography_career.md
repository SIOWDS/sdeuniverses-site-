# 第一编与第三编参考文献

Acemoglu, Daron, and Pascual Restrepo. 2019. “Automation and New Tasks: How Technology Displaces and Reinstates Labor.” Journal of Economic Perspectives 33(2): 3–30. https://doi.org/10.1257/jep.33.2.3 . 作者机构存档：https://dspace.mit.edu/entities/publication/91aa5fad-e508-4847-9e33-62a1a5db8f11 .

AlphaProof and AlphaGeometry Teams. 2024. “AI Achieves Silver-Medal Standard Solving International Mathematical Olympiad Problems.” Google DeepMind, July 25. https://deepmind.google/blog/ai-solves-imo-problems-at-silver-medal-level/ .

Autor, David H. 2015. “Why Are There Still So Many Jobs? The History and Future of Workplace Automation.” Journal of Economic Perspectives 29(3): 3–30. https://doi.org/10.1257/jep.29.3.3 . 作者机构全文：https://economics.mit.edu/sites/default/files/publications/why%20are%20there%20still%20jobs%202014.pdf .

Davies, Alex, Petar Veličković, Lars Buesing, et al. 2021. “Advancing Mathematics by Guiding Human Intuition with AI.” Nature 600: 70–74. https://doi.org/10.1038/s41586-021-04086-x .

Lean Language Reference. “Validating a Lean Proof.” https://lean-lang.org/doc/reference/latest/ValidatingProofs/ . 检索日期：2026年10月11日。

Luong, Thang, and Edward Lockhart. 2025. “Advanced Version of Gemini with Deep Think Officially Achieves Gold-Medal Standard at the International Mathematical Olympiad.” Google DeepMind, July 21. https://deepmind.google/blog/advanced-version-of-gemini-with-deep-think-officially-achieves-gold-medal-standard-at-the-international-mathematical-olympiad/ .
