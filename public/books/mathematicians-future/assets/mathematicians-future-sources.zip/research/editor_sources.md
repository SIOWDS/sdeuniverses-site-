# 总编辑引用资料

1. AlphaProof and AlphaGeometry teams. AI achieves silver-medal standard solving International Mathematical Olympiad problems. Google DeepMind, 2024-07-25（页面含2025-11-12研究发表更新）. https://deepmind.google/blog/ai-solves-imo-problems-at-silver-medal-level/ 。导论仅引用竞赛分数标准，不展开技术细节。读者应参看第二章对人工形式化与时限不同的说明。
2. Thang Luong and Edward Lockhart. Advanced version of Gemini with Deep Think officially achieves gold-medal standard at the International Mathematical Olympiad. Google DeepMind, 2025-07-21. https://deepmind.google/blog/advanced-version-of-gemini-with-deep-think-officially-achieves-gold-medal-standard-at-the-international-mathematical-olympiad/ 。导论仅概述分数标准。官方页面特别限定：IMO确认答案完整正确，不验证系统、过程或底层模型。

访问日期：2026-10-11。两项皆为研究机构公告，不能将其宣传愿景视作独立数学职业趋势证据。
