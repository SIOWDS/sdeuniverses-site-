# 第四编及附录参考文献

Kuhn, Thomas S. 1970. *The Structure of Scientific Revolutions*. 2nd ed., enlarged. Chicago: University of Chicago Press. 原作初版1962年；含1969年后记。https://www.lri.fr/~mbl/Stanford/CS477/papers/Kuhn-SSR-2ndEd.pdf

Kuhn, Thomas S. 2012. *The Structure of Scientific Revolutions: 50th Anniversary Edition*. Introduction by Ian Hacking. Chicago: University of Chicago Press. https://press.uchicago.edu/ucp/books/book/chicago/S/bo13179781.html

Einstein, Albert. 1905. “Zur Elektrodynamik bewegter Körper.” *Annalen der Physik*, 17: 891–921. 英译题名：*On the Electrodynamics of Moving Bodies*. https://sites.pitt.edu/~jdnorton/teaching/HPS_0410/chapters/origins_pathway/On-the_electrodynamics/index.html

Lee, John M. 2013. *Axiomatic Geometry*. Pure and Applied Undergraduate Texts, Vol. 21. Providence, RI: American Mathematical Society. https://sites.math.washington.edu/~lee/Books/AG/amstext-21-prev.pdf

University of Glasgow. n.d. “Other Models of Hyperbolic Geometry.” Mathematics lecture notes. https://www.maths.gla.ac.uk/wws/cabripages/klein/models.html （访问日期：2026年10月11日。）

Romera-Paredes, Bernardino, et al. 2024. “Mathematical Discoveries from Program Search with Large Language Models.” *Nature*, 625: 468–475. 在线发表于2023年12月14日。https://doi.org/10.1038/s41586-023-06924-6

Lean Project. n.d. “Validating a Lean Proof.” *The Lean Language Reference*. https://lean-lang.org/doc/reference/latest/ValidatingProofs/ （访问日期：2026年10月11日。）

Udrescu, Silviu-Marian, and Max Tegmark. 2020. “AI Feynman: A Physics-Inspired Method for Symbolic Regression.” *Science Advances*, 6: eaay2631. https://doi.org/10.1126/sciadv.aay2631 ; 作者存档：https://arxiv.org/abs/1905.11481

Merchant, Amil, et al. 2023. “Scaling Deep Learning for Materials Discovery.” *Nature*, 624: 80–85. https://doi.org/10.1038/s41586-023-06735-9

Szymanski, Nathan J., et al. 2023. “An Autonomous Laboratory for the Accelerated Synthesis of Inorganic Materials.” *Nature*, 624: 86–91. 现行更正题名；初发表题名使用“Novel Materials”。https://doi.org/10.1038/s41586-023-06734-w

Szymanski, Nathan J., et al. 2026. “Author Correction: An Autonomous Laboratory for the Accelerated Synthesis of Inorganic Materials.” *Nature*, 650: E1. 在线发表于2026年1月19日。https://doi.org/10.1038/s41586-025-09992-y

Abramson, Josh, et al. 2024. “Accurate Structure Prediction of Biomolecular Interactions with AlphaFold 3.” *Nature*, 630: 493–500. https://doi.org/10.1038/s41586-024-07487-w

Roohani, Yusuf, Kexin Huang, and Jure Leskovec. 2024. “Predicting Transcriptional Outcomes of Novel Multigene Perturbations with GEARS.” *Nature Biotechnology*, 42: 927–935. 在线发表于2023年8月17日。https://doi.org/10.1038/s41587-023-01905-6

