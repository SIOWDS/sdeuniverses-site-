# 第一编与第三编研究记录

检索日期：2026-10-11（中国时间）。正文中的制度分析、假想案例及方案为本书论证，不冒充实证研究。

1. AlphaProof and AlphaGeometry teams. 2024-07-25. AI achieves silver-medal standard solving International Mathematical Olympiad problems. Google DeepMind. https://deepmind.google/blog/ai-solves-imo-problems-at-silver-medal-level/ 。已读正文。系统解出2024 IMO六题中的四题，28/42达到银牌分数；题目人工形式化，部分任务用时最长三天。不把它表述为同条件参赛或研究数学全面替代。
2. Thang Luong and Edward Lockhart. 2025-07-21. Advanced version of Gemini with Deep Think officially achieves gold-medal standard at the International Mathematical Olympiad. Google DeepMind. https://deepmind.google/blog/advanced-version-of-gemini-with-deep-think-officially-achieves-gold-medal-standard-at-the-international-mathematical-olympiad/ 。已读正文。高级版本在2025题目中五题满分35/42，机构报告称由IMO协调方按同样标准评分认证；自然语言端到端，在比赛时限内。只用于说明输入、推理、验证组织变化，不推断全体数学职业已可替代。
3. Alex Davies et al. 2021. Advancing mathematics by guiding human intuition with AI. Nature 600, 70–74. DOI 10.1038/s41586-021-04086-x. https://www.nature.com/articles/s41586-021-04086-x 。已读摘要及主要研究部分。结理论中的代数/几何不变量联系，及表示论中关于KL多项式的候选方案。原始候选关系遭反例修改；没有声称完全解决组合不变性猜想。正文只简述相关工作，讨论部分是本书独立推论。
4. Lean Language Reference. Validating a Lean Proof. https://lean-lang.org/doc/reference/latest/ValidatingProofs/ 。已读完整验证说明。核验在定义、定理、公理体系内的证明；形式陈述是否对应原意仍需检查，依赖公理与库亦需检查。不把形式化通过等于应用真实性或无条件绝对正确。
5. Daron Acemoglu and Pascual Restrepo. 2019. Automation and New Tasks: How Technology Displaces and Reinstates Labor. Journal of Economic Perspectives 33(2), 3–30. DOI 10.1257/jep.33.2.3. https://dspace.mit.edu/entities/publication/91aa5fad-e508-4847-9e33-62a1a5db8f11 ; https://shapingwork.mit.edu/research/automation-and-new-tasks-how-technology-displaces-and-reinstates-labor/ 。读取原作者机构记录及摘要。任务框架区分自动化替代与新任务恢复劳动需求；本书数学职业分析是扩展应用，不称论文直接研究数学家。
6. David H. Autor. 2015. Why Are There Still So Many Jobs? The History and Future of Workplace Automation. Journal of Economic Perspectives 29(3), 3–30. DOI 10.1257/jep.29.3.3. https://dspace.mit.edu/entities/publication/d150847d-0448-49cd-a76f-0cd9b5331ac9 。已读作者机构存档摘要。替代与互补、产出扩张、劳动供给调整不能只看其中一项；正文不以该文2015年对AI能力边界的判断作为今日边界。

引用约束：不使用直接长引文；每一来源事实简介控制在简短段落。未进行职业调查，不报告数学家失业率、AI使用率等数字。示意公式为条件模型，不是数据拟合结果。

## 补充核对与统稿修订

- 已进一步实际阅读Autor原作者MIT全文PDF第6—7印刷页（PDF第4—5页）：https://economics.mit.edu/sites/default/files/publications/why%20are%20there%20still%20jobs%202014.pdf 。第11章加入其依据Bessen研究叙述的ATM/柜员复杂历史案例，明确美国1980—2010的时间区间，约50万至55万；同时区分就业绝对量与份额，说明网点扩展和任务重组，不作为今日银行业现状或未来普遍定律。Bessen原文未成功直接取得，故正文引用Autor而不冒称直接读过Bessen。
- 第02章按交叉审读意见移除未经资料支持的“初步解题岗位”称呼，改为有条件的研究机会变化。
- 第13章改为相同观测投影与不同隐藏历史，避免把非充分观测称作完整状态。
- 第13章加入明确示意时间账：总时间1，候选生成0.1提速10倍后总时间0.91，总加速约1.10；额外核验0.09抵消收益。不是测量结果。
- 第13章以三格状态甲(1,0,0)、乙(0,1,0)及只将第一格减半的更新，展示总和观测不支持封闭更新；为普通线性算例，不声称新定理，区别于第六编正式伞模型。
- 01—05与11—15均为原创正文，不作现成材料的长摘要；实际参考书目另见bibliography_career.md。
