# 附录一《多元科学发生》团队交叉检查

检查性质：写作团队内部交叉检查，不是外部同行评议。已完整阅读chapters/37.md七节及chapters/38.md八节，并回查主要科学事实的一手来源。未修改其他作者正文。

## 总体结论

主要事实支持充分，未发现预测结果冒充数学证明、计算稳定性冒充已合成材料，或结构预测冒充生命机制已获解释的硬伤。文中明确区分：数学证明的条件性；物理测量、模拟误差与可区别预测；化学合成、表征与新颖性；生物层级、干预和跨情境验证。假想衰减模型、反应网络和实验室方案均以例子或假想方式呈现，未伪造实证结果。对SDE的作用定位为研究纲领，未以哲学术语替代实验。

## 必要精度修订（共3项）

1. **第三节GNoME的“结构稳定性”进一步限定。** 建议写为“在给定DFT计算设置与竞争相参照下的热力学稳定性评估”，避免普通读者把稳定理解为常温耐久、动力学稳定或易合成。正文已经正确说不能等同合成与规模生产，本条只是把计算证据的对象写全，不需要添加大量材料数量。

2. **第四节AlphaFold 3的“候选构象”避免被读成动态集合。** 原论文明确说明其随机种子生成结果不近似真实溶液构象集合。建议在结构预测与动态过程之间加一句：“不同随机种子的候选结构，并不因此构成经验证的真实动态构象分布。”正文现有边界基本正确，加此句可以直接防止把生成多样性当成生命动力学。

3. **第三节A-Lab更正保留作者复核性质，书目匹配正确年份。** 可将“重新分析确认了”精化为“作者重新分析衍射图谱后报告确认了”，避免误读为本书或独立实验室完成复现实验。36/40及4项XRD单独不足定论均有原更正支持，无须改数。更正DOI虽含025，实际发表为2026年1月19日，书末应列2026；原2023论文题名宜采用更正后的版本，并同时列更正条目。

## 已核验的一手资料

- Udrescu, S.-M., and Tegmark, M. AI Feynman: A physics-inspired method for symbolic regression. Science Advances 6, eaay2631 (2020). DOI:10.1126/sciadv.aay2631. 原研究确为神经网络与物理启发的符号回归，基准包括已知公式。https://pmc.ncbi.nlm.nih.gov/articles/PMC7159912/ ; https://arxiv.org/abs/1905.11481
- Merchant, A., et al. Scaling deep learning for materials discovery. Nature 624, 80–85 (2023). DOI:10.1038/s41586-023-06735-9. 已读原文的DFT、竞争相凸包、主动学习循环及实验匹配段落。https://www.nature.com/articles/s41586-023-06735-9
- Szymanski, N. J., et al. An autonomous laboratory for the accelerated synthesis of inorganic materials. Nature 624, 86–91 (2023). DOI:10.1038/s41586-023-06734-w. 本条采用更正后题名。https://www.nature.com/articles/s41586-023-06734-w
- Szymanski, N. J., et al. Author Correction: An autonomous laboratory for the accelerated synthesis of inorganic materials. Nature 650, E1 (2026). DOI:10.1038/s41586-025-09992-y. 官方更正及PMC全文支持“平台新而未必科学新”和36/40复核结论。https://www.nature.com/articles/s41586-025-09992-y ; https://pmc.ncbi.nlm.nih.gov/articles/PMC12872444/
- Abramson, J., et al. Accurate structure prediction of biomolecular interactions with AlphaFold 3. Nature 630, 493–500 (2024). DOI:10.1038/s41586-024-07487-w. 已读结构组成、扩散模块和静态结构/动态集合限制。https://www.nature.com/articles/s41586-024-07487-w
- Roohani, Y., Huang, K., and Leskovec, J. Predicting transcriptional outcomes of novel multigene perturbations with GEARS. Nature Biotechnology 42, 927–935 (2024；在线发表于2023年). DOI:10.1038/s41587-023-01905-6. 官方结果支持深度学习与基因关系图结合及指定扰动任务评估。https://www.nature.com/articles/s41587-023-01905-6

上述每条为短范围说明，不把机构报告或单篇论文提升为普遍能力结论。未发现需要重新组织附录一结构的问题。

## 修订复核与附录二检查

附录一以上三项精度修订均已在正文核实落实。GNoME已限定给定密度泛函计算与竞争相参照；AlphaFold 3已排除把随机种子输出当真实动态构象集合；A-Lab已明确是作者重新分析后的报告。参考文献应在总装配时保留2026更正条目。

附录二与附录一形成互补，未发现必须增加的第四、第五项修订。附录一着重学科证据与科学研究约束；附录二着重活动与实现方式的分离、典范构成条件对象化、局部稳定与多路径发生、复合主体和制度安排。两篇提及反馈与检验的地方服务于不同层级，尚不构成应删的整段重复。

交通类比已明确是一种思想比较，且承认早期骑乘、舟船及其他轮式交通，没有宣称汽车出现以前人只能步行。由交通活动多元化转向理念多元化，被写作研究方向和可检验的组织条件，没有把类比当作AI必然带来新典范的历史证明。末节还明确保留需求扩张、公共支持、分配与领域差异。

对库恩的论述承认先典范阶段的学派、专业共同体及后记中的细化；“超越”被准确限定为本书主张的发生学拓展，未声称库恩认为全体科学只能有一个典范，未冒充哲学界已认可的结论。复合主体中的SDE关系式也明说是互生关系提示，不是已经可计算的科学定律。

附录二末节列出候选实质差异、发现缺陷的时间、独立接续、验证成本及资源集中等可观察方向，同时说明失败可能，足以承接附录一对候选数量不等于科学质量的约束。两附录现有论证可以进入总编排版。
