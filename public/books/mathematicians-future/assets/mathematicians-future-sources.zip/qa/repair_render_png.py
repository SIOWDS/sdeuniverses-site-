"""Verify every rendered page fully decodes; reconstruct broken/missing pages from PDF."""
from pathlib import Path
import sys,json
import fitz
from PIL import Image
folder=Path(sys.argv[1]);pdfs=list(folder.glob('*.pdf'))
assert len(pdfs)==1,pdfs
pdf=fitz.open(pdfs[0]);fixed=[]
for i in range(len(pdf)):
    path=folder/f'page-{i+1}.png'
    try:
        with Image.open(path) as im:im.load()
    except Exception:
        pdf[i].get_pixmap(matrix=fitz.Matrix(2,2),alpha=False).save(path)
        with Image.open(path) as im:im.load()
        fixed.append(i+1)
result={'pdf':str(pdfs[0]),'pages':len(pdf),'fully_decoded_pngs':len(pdf),'repaired_pages':fixed}
(folder/'png_integrity.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False))
