from pathlib import Path
from zipfile import ZipFile
import re,json
from lxml import etree as E
R=Path(__file__).resolve().parents[1]
f=R/'output'/'面对AI的冲击_数学家走向何处_全稿_v1.0.docx'
ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main','m':'http://schemas.openxmlformats.org/officeDocument/2006/math'}
def cn(t):return ''.join(re.findall(r'[\u3400-\u9fff]',t))
with ZipFile(f) as z:
    tree=E.fromstring(z.read('word/document.xml'))
    text=''.join(tree.xpath('//w:t/text() | //m:t/text()',namespaces=ns));whole=cn(text)
    missing=[];checked=0
    for p in sorted((R/'chapters').glob('*.md')):
        for block in p.read_text().split('\n\n'):
            if block.startswith('#') or block.startswith('```'):continue
            frag=cn(block)
            if len(frag)<50:continue
            checked+=1
            if frag not in whole:missing.append({'file':p.name,'prefix':frag[:90]})
    bookmarks=tree.xpath('//w:bookmarkStart/@w:name',namespaces=ns)
    links=tree.xpath('//w:hyperlink/@w:anchor',namespaces=ns)
    result={'source_paragraphs_checked':checked,'missing_paragraphs':missing,'native_equations':len(tree.xpath('//m:oMath',namespaces=ns)),'inline_figures':len(tree.xpath('//w:drawing',namespaces=ns)),'missing_internal_link_targets':sorted(set(links)-set(bookmarks)),'contains_placeholder':'PLACEHOLDER' in text or '000' in text[:3000]}
    (R/'qa'/'docx_integrity.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps(result,ensure_ascii=False))
