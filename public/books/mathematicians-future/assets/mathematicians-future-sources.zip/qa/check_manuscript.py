from pathlib import Path
from collections import Counter, defaultdict
import re, json

ROOT=Path(__file__).resolve().parents[1]
TARGET={0:6000,**{i:3500 for i in range(1,5)},5:4000,**{i:7000 for i in range(6,11)},**{i:4000 for i in range(11,16)},16:4000,17:4000,18:5000,19:4500,20:4500,**{i:5000 for i in range(21,26)},**{i:6000 for i in range(26,31)},**{i:5000 for i in range(31,36)},36:4000,37:15000,38:10000}
def body_count(text):
    text=re.sub(r'```.*?```','',text,flags=re.S)
    lines=[]
    for line in text.splitlines():
        if line.startswith('#'): continue
        if re.match(r'^\s*\[?\d+\]?\.?\s+https?://',line):continue
        lines.append(line)
    return len(re.findall(r'[\u3400-\u9fff]', '\n'.join(lines)))

def audit():
    rec=[];para=defaultdict(list);flags=[]
    for i,target in TARGET.items():
        p=ROOT/'chapters'/f'{i:02}.md'
        if not p.exists():rec.append({'file':p.name,'target':target,'actual':0,'status':'missing'});continue
        s=p.read_text();count=body_count(s)
        rec.append({'file':p.name,'title':s.splitlines()[0].lstrip('# '),'target':target,'actual':count,'status':'pass' if count>=target else 'short'})
        for block in s.split('\n\n'):
            n=re.sub(r'\W','',block)
            if len(n)>70 and not block.startswith('#'):para[n].append(p.name)
        for token in ['TODO','待补正文','此处省略','turn0search','','待续','继续写作提示']:
            if token in s:flags.append({'file':p.name,'token':token})
    duplicates=[{'files':files,'prefix':txt[:100]} for txt,files in para.items() if len(files)>1]
    result={'count_rule':'去标题、代码块后的U+3400—U+9FFF汉字；参考文献独立存放，不计入正文','total':sum(r['actual'] for r in rec),'target_total':sum(TARGET.values()),'chapters':rec,'duplicate_paragraphs':duplicates,'flags':flags}
    (ROOT/'qa'/'manuscript_audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    return result

if __name__=='__main__':
    a=audit()
    print(json.dumps({'total':a['total'],'passed':sum(x['status']=='pass' for x in a['chapters']),'written':sum(x['actual']>0 for x in a['chapters']),'duplicate_paragraphs':len(a['duplicate_paragraphs']),'flags':a['flags'],'short':[(x['file'],x['actual'],x['target']) for x in a['chapters'] if x['status']!='pass']},ensure_ascii=False))
