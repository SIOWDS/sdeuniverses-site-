from pathlib import Path
import fitz,json,sys,re
R=Path(__file__).resolve().parents[1]
f=Path(sys.argv[1]);doc=fitz.open(f)
issues=[]
for i,p in enumerate(doc):
    txt=p.get_text()
    if '\ufffd' in txt:issues.append({'page':i+1,'type':'replacement_character'})
    if len(txt.strip())<2 and not p.get_images():issues.append({'page':i+1,'type':'empty_page'})
    for b in p.get_text('dict')['blocks']:
        if b['type']!=0:continue
        for line in b['lines']:
            x0,y0,x1,y1=line['bbox']
            if x0<-1 or y0<-1 or x1>p.rect.width+1 or y1>p.rect.height+1:
                issues.append({'page':i+1,'type':'outside_page','text':''.join(s['text'] for s in line['spans'])[:120],'bbox':[x0,y0,x1,y1]})
result={'file':f.name,'pages':len(doc),'page_size_pt':list(doc[0].rect),'outline_entries':len(doc.get_toc()),'link_count':sum(len(p.get_links()) for p in doc),'issues':issues}
(R/'qa'/(f.stem+'_geometry.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False))
