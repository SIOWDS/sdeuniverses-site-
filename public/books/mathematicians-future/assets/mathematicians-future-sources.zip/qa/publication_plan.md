# 新书发布路径核验

核验日：2026-10-11。现有仓库 `SIOWDS/sdeuniverses-site-`，现有站点 `https://sdeuniverses.com`。本报告仅说明本次出版的路径；第220、302号专著仅作只读版式参照。

## 现有部署

README 明确主分支推送由 Cloudflare Workers Builds 自动部署。`wrangler.jsonc` 的入口为 `src/worker.js`，静态目录为 `public/`，绑定名 `ASSETS`，Worker 名 `steep-band-faf5`。无需建立另一个 Sites 项目。GitHub GitData 的 blob/tree/commit/update_ref 能力已由主代理确认，可将本次允许的文件一次提交到最新 main；更新 ref 必须非强制，并以新取得的 main 为父提交，避免覆盖并发修改。

## 目录与三书架

`public/books/catalog.json` 是唯一书目源。`tools/build_bookshelf.py` 生成以下三处：

- `public/books/index.html` → `/books/`
- `public/monographs/index.html` → `/monographs/`
- `public/sites/read/library/index.html` → `read.sdeuniverses.com/library/`

已检查的书目含333条，`math` 分类为“数学与科学”。新增书采用稳定独立 ID `mathematicians-future`，路径 `/books/mathematicians-future/`。书目保留 `number: null`（生成器直接读取该字段），不编造卷号、ISBN、定价。`readMode: full`，`readUrl` 与 `flipUrl` 同指实际翻页页，`chapterUrl` 指章节目录，`pdfUrl` 指真实阅读版。上线时间为实际数字版上线时间。

**生成器存在广域副作用：**原脚本在生成三书架后自动调用 `build_book_agents.py` 和 `inject_book_agent.py --apply`。本次在隔离目录使用保留原渲染函数的受限副本，只执行三书架生成，读取现有 `agents.json` 保持既有书生名称；不运行注入。提交白名单仅含新书目录、catalog 和三书架，不含其他书页或 agents 文件。提交前将其他书目记录逐条与最新基线比较。

## 本次新增文件

`public/books/mathematicians-future/` 内包括：`index.html`、`read.html`、`chapters.html`、`text/index.html`、39个 `text/chapter-NN.html`、`assets/book.css`、`assets/book.js`、`assets/cover.png` 以及以下四种配套文件：

- `assets/mathematicians-future-reading.pdf`
- `assets/mathematicians-future-print.pdf`
- `assets/mathematicians-future.docx`
- `assets/mathematicians-future-sources.zip`

阅读页复用302号已运行的 PDF.js 3.11.174 矢量阅读器逻辑，替换书名、独立存储键、PDF地址及真实目录页码。保留 `fontExtraProperties: true`、`isOffscreenCanvasSupported: false`、标准字体与 CMap 参数；使用 SVG 为主和逐页位图回退。目录读取最终验证的物理页码，不能沿用参考书页码。全文由39章 Markdown 构建，数学使用 Pandoc MathML。

## 发布规则与验证

`.github/workflows/search-index.yml` 明确搜索索引只在每天北京时间23:20定时更新。本次不触发人工 reindex，不添加发布触发器。

`docs/pdf-storage-scope.md` 是9月旧规则；10月2日后的 `.github/workflows/pdf-offload.yml` 已明确所有公开PDF稳定24小时后可自动转存R2，保持URL。本次可先将新PDF与站点文件正常提交，不手工删除或改变既有PDF存储方式，不主动触发转存。

校验包括：39章标题与来源相同、全文无遗漏、全部本地新书链接可解析、PDF目录等于验证页码、MathML保留公式、四类下载存在、三书架各仅新增本书一条、220/302路径完全不在提交集。正式发布还需检查线上页面、PDF响应及阅读器实际载入结果。

## 核对的仓库材料

`README.md`、`wrangler.jsonc`、`docs/bookshelf-maintenance.md`、`docs/pdf-storage-scope.md`、`.github/workflows/search-index.yml`、`.github/workflows/pdf-offload.yml`、`tools/build_bookshelf.py`、`public/books/catalog.json`、`public/books/agents.json`、220与302的目录和 `read.html`。根目录及 `public/`、`public/books/`、`tools/` 的 `AGENTS.md` 均未发现（GitHub404）。已核对的 main 快照为 `62f60a3c436fee16bc4e10227afff79442613bea`；正式提交前须再刷新。
