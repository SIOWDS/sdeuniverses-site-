from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import json,re,hashlib,ast
R=Path(__file__).resolve().parent; O=R/'output'
a=json.loads((R/'qa/manuscript_audit.json').read_text())
text=(O/'完整正文.md').read_text().replace(str(R)+'/','')
if '[[INDEX_PLACEHOLDER]]' in text:
    index=json.loads((R/'qa/verified_page_map.json').read_text())
    tree=ast.parse((R/'finalize_navigation.py').read_text())
    topics=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='topics' for t in n.targets))
    text=text.replace('[[INDEX_PLACEHOLDER]]','\n\n'.join(topic+'：'+ '、'.join(str(index[str(i)]) for i in ids)+'页' for topic,ids in topics.items()))
if '[[COVER_PLACEHOLDER]]' in text:text=text.replace('[[COVER_PLACEHOLDER]]','![封面](figures/cover.png)')
if '[[TOC_PLACEHOLDER]]' in text:
    links='\n'.join('- '+x['title'] for x in a['chapters'])
    text=text.replace('[[TOC_PLACEHOLDER]]',links)
(O/'完整正文.md').write_text(text)
readme=f'''# 面对AI的冲击，数学家走向何处？

王德生著。数字阅读版 v1.0，2026年10月。副标题：从常规解题到人—AI复合体的多元数学发生。

本包保存七编三十五章、导论、结语与两篇附录的完整文本，以及前言、导读、书目、数学代码和制作文件。正文为{a['total']:,}个汉字；统计排除标题、程序、参考文献与编辑辅文。所有章节均达到原分配篇幅，第二附录为追加内容。

在线入口：https://sdeuniverses.com/books/mathematicians-future/

## 阅读与复现

`完整正文.md`为连续文本，`chapters/00.md`至`38.md`为分章底本。Word保留原生数学公式；阅读PDF为190×250毫米，印刷PDF为170×240毫米，两者保留同一页码。

`code/README.md`说明有限伞模型。进入code目录后，以Python 3运行：

```bash
python umbrella_model.py
python -m unittest -v test_umbrella_model.py
```

程序使用标准库和精确有理数；11项测试已实际运行通过。测试覆盖有限算例、二维观察闭合、饱和运算和同维线性基线；一般性结论以第六编的证明为准，合成数据不是人体实验。

## 文稿与制作材料

`frontmatter/`保存前后辅文；`research/`保存分编书目与核验记录；`figures/`保存专属封面艺术、排版封面及两幅精确算例图；`qa/`保存内部交叉审稿、正文计数、完整性与版式检查记录。内部审读不等于外部同行评议。

根目录脚本保存Word/PDF装配流程，需要Python的python-docx、PyMuPDF、Pillow、matplotlib及Pandoc，并使用Noto Serif CJK SC、Noto Sans CJK SC和Latin Modern Math字体。Word转PDF的具体命令依运行环境而定，最终页码需在渲染后重新核定。

`site/`保存新增书页和生成脚本，绝不要求用旧catalog覆盖生产站。再次发布时须先读取网站最新书目，生成最小增量，并保持其他专著不变。下载资产独立交付；配套包不重复嵌套自身。

版权与协作方式见书中《出版与版本说明》。封面使用图像生成创作，书名和出版信息以真实排版文字叠印；数学图依据正文数值绘制。
'''
(O/'README.txt').write_text(readme)
archive=O/'mathematicians-future-sources.zip'
files=[(O/'README.txt','README.md'),(O/'完整正文.md','完整正文.md')]
for folder in ['chapters','frontmatter','code','research','figures']:
    for p in sorted((R/folder).rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts and p.suffix in ['.md','.json','.py','.png']:
            if p.name in ['format_math.py','finalize_math.py']:continue
            files.append((p,str(p.relative_to(R))))
for name in ['build_book.py','make_figures.py','finalize_navigation.py','finish_pdf.py','package_book.py']:
    files.append((R/name,name))
for p in sorted((R/'qa').glob('*')):
    if p.is_file() and p.suffix in ['.md','.json','.py'] and not any(x in p.name for x in ['sample','before_design','reference_design','front_navigation']):
        files.append((p,str(p.relative_to(R))))
for p in sorted((R/'site').rglob('*')):
    if not p.is_file() or '__pycache__' in p.parts:continue
    if p.suffix not in ['.py','.css','.js','.html','.json','.md']:continue
    if p.name in ['publish-manifest.json','qa-report.json']:continue
    if '/public/' in str(p) and '/mathematicians-future/' not in str(p):continue
    files.append((p,str(p.relative_to(R))))
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=8) as z:
    for p,name in files:z.write(p,name)
with ZipFile(archive) as z:
    assert z.testzip() is None
print(json.dumps({'archive':str(archive),'files':len(files),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},ensure_ascii=False))
