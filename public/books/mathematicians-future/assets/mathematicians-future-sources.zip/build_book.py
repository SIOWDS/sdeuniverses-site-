from pathlib import Path
import sys,re,subprocess,json,copy
from docx import Document
from docx.shared import Inches,Pt,Mm,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH,WD_TAB_ALIGNMENT,WD_TAB_LEADER,WD_LINE_SPACING
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.section import WD_SECTION_START
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.text.paragraph import Paragraph
from PIL import Image

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'output';OUT.mkdir(exist_ok=True)
QA=ROOT/'qa';QA.mkdir(exist_ok=True)
TITLE='面对AI的冲击，数学家走向何处？'
SUBTITLE='从常规解题到人—AI复合体的多元数学发生'
NAVY='173149';GOLD='B58E4A';PAPER='FAF7F0';INK='243441';GRAY='89919A';PALE='E7D8B8'
SERIF='Noto Serif CJK SC';SANS='Noto Sans CJK SC'
PARTS={1:'第一编 AI冲击与数学家的生涯转折',6:'第二编 工具革命与新行业涌现的历史',11:'第三编 从职业替代到新研究阵地的发生',16:'第四编 从库恩的常规科学到数学典范多元化',21:'第五编 SDE视野中的多元数学发生',26:'第六编 人—AI典范实验室：发明新的数模型',31:'第七编 数学生涯、教育与共同体的升级'}
FRONTS=[('publication','出版与版本说明'),('author','作者介绍'),('preface','前言'),('reader_guide','导读')]

def set_font(target,size=11.4,bold=False,color=INK,family=SERIF):
    target.font.name=family;target.font.size=Pt(size);target.font.bold=bold;target.font.color.rgb=RGBColor.from_string(color)
    if hasattr(target,'element'):rpr=target.element.get_or_add_rPr()
    else:rpr=target._element.get_or_add_rPr()
    rf=rpr.find(qn('w:rFonts'))
    if rf is None:rf=OxmlElement('w:rFonts');rpr.insert(0,rf)
    for k in ['ascii','hAnsi','eastAsia','cs']:rf.set(qn('w:'+k),family)
    for k in ['asciiTheme','hAnsiTheme','eastAsiaTheme','cstheme']:rf.attrib.pop(qn('w:'+k),None)

def border(p,side='bottom',color=GOLD,size=4,space=8):
    pp=p._p.get_or_add_pPr();b=pp.find(qn('w:pBdr'))
    if b is None:b=OxmlElement('w:pBdr');pp.append(b)
    el=OxmlElement('w:'+side)
    for k,v in [('val','single'),('sz',str(size)),('space',str(space)),('color',color)]:el.set(qn('w:'+k),v)
    b.append(el)

def shade(p,color=PAPER):
    el=OxmlElement('w:shd');el.set(qn('w:fill'),color);el.set(qn('w:val'),'clear');p._p.get_or_add_pPr().append(el)

def setup(doc):
    for sec in doc.sections:
        sec.page_width=Mm(190);sec.page_height=Mm(250)
        sec.top_margin=Mm(20);sec.bottom_margin=Mm(20);sec.left_margin=Mm(18);sec.right_margin=Mm(18)
        sec.header_distance=Mm(8.5);sec.footer_distance=Mm(8)
    for name in ['Normal','Body Text','First Paragraph']:
        if name not in doc.styles:doc.styles.add_style(name,WD_STYLE_TYPE.PARAGRAPH)
        st=doc.styles[name];set_font(st)
        f=st.paragraph_format;f.line_spacing=Pt(20.5);f.line_spacing_rule=WD_LINE_SPACING.EXACTLY
        f.space_after=Pt(4.5);f.first_line_indent=Pt(22.8);f.widow_control=True;f.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY
    for name,size in [('Title',29),('Subtitle',12.5)]:
        set_font(doc.styles[name],size,name=='Title',NAVY)
        pf=doc.styles[name].paragraph_format;pf.space_after=Pt(14);pf.first_line_indent=Pt(0);pf.line_spacing=1.15;pf.keep_with_next=True
        doc.styles[name].font.italic=False
    for lev,size in [(1,18),(2,12.2),(3,11.4)]:
        st=doc.styles['Heading '+str(lev)];set_font(st,size,True,NAVY,SERIF if lev==1 else SANS)
        pf=st.paragraph_format;pf.first_line_indent=Pt(0);pf.space_before=Pt(16 if lev>1 else 0);pf.space_after=Pt(9)
        pf.keep_with_next=True;pf.page_break_before=lev==1;pf.line_spacing=1.3;pf.alignment=WD_ALIGN_PARAGRAPH.LEFT
    specs=[('TOC Entry',10.3,False,INK,SANS),('Part Number',58,False,PALE,SERIF),('Part Title',22,True,NAVY,SERIF),('Part Label',10,True,GOLD,SANS),('Part Intro',11.4,False,INK,SERIF),('Book Metadata',10.5,False,INK,SANS),('References',9.3,False,INK,SANS),('Code',8.5,False,INK,'Liberation Mono'),('Front Title',19,True,NAVY,SERIF),('Chapter Quote',10.5,False,NAVY,SERIF),('Cover Kicker',18,False,PAPER,SERIF),('Cover Main',34,True,PAPER,SERIF),('Cover Sub',12.5,False,PALE,SANS),('Cover Author',12,False,PAPER,SANS),('Back Title',23,True,PAPER,SERIF),('Back Text',11.5,False,PAPER,SERIF)]
    for name,size,bold,col,fam in specs:
        if name not in doc.styles:doc.styles.add_style(name,WD_STYLE_TYPE.PARAGRAPH)
        st=doc.styles[name];set_font(st,size,bold,col,fam)
        pf=st.paragraph_format;pf.first_line_indent=Pt(0);pf.space_after=Pt(7);pf.line_spacing=1.35;pf.widow_control=True
    doc.styles['References'].paragraph_format.line_spacing=Pt(16)
    doc.styles['References'].paragraph_format.first_line_indent=Pt(-12)
    doc.styles['References'].paragraph_format.left_indent=Pt(12)
    doc.styles['TOC Entry'].paragraph_format.tab_stops.add_tab_stop(Mm(152),WD_TAB_ALIGNMENT.RIGHT,WD_TAB_LEADER.DOTS)
    for name in ['Front Title','Part Title']:
        pf=doc.styles[name].paragraph_format;pf.keep_with_next=True
        pp=doc.styles[name].element.get_or_add_pPr();outline=OxmlElement('w:outlineLvl');outline.set(qn('w:val'),'0');pp.append(outline)
    for name in ['Cover Kicker','Cover Main','Cover Sub','Cover Author','Front Title','Back Title','Back Text']:
        doc.styles[name].paragraph_format.alignment=WD_ALIGN_PARAGRAPH.LEFT
    doc.styles['Chapter Quote'].paragraph_format.left_indent=Pt(10)
    doc.styles['Chapter Quote'].paragraph_format.right_indent=Pt(9)
    doc.styles['Chapter Quote'].paragraph_format.line_spacing=Pt(18)
    doc.styles['Chapter Quote'].paragraph_format.space_before=Pt(6)
    doc.styles['Chapter Quote'].paragraph_format.space_after=Pt(14)
    doc.styles['Chapter Quote'].paragraph_format.keep_with_next=True
    for name in ['Caption','Image Caption']:
        if name in doc.styles:
            set_font(doc.styles[name],9,False,GRAY,SANS);doc.styles[name].font.italic=False
    if 'Hyperlink' not in doc.styles:doc.styles.add_style('Hyperlink',WD_STYLE_TYPE.CHARACTER)
    doc.styles['Hyperlink'].font.color.rgb=RGBColor.from_string(NAVY)
    doc.styles['Hyperlink'].font.underline=False
    if 'Verbatim Char' not in doc.styles:doc.styles.add_style('Verbatim Char',WD_STYLE_TYPE.CHARACTER)
    set_font(doc.styles['Verbatim Char'],9,False,INK,'Liberation Mono')
    set_font(doc.styles['Code'],9,False,INK,'Liberation Mono')
    cf=doc.styles['Code'].paragraph_format;cf.alignment=WD_ALIGN_PARAGRAPH.LEFT;cf.first_line_indent=Pt(0);cf.line_spacing=Pt(15);cf.space_after=Pt(10)
    mp=doc.settings.element.find(qn('m:mathPr'))
    if mp is None:mp=OxmlElement('m:mathPr');doc.settings.element.append(mp)
    mf=mp.find(qn('m:mathFont'))
    if mf is None:mf=OxmlElement('m:mathFont');mp.append(mf)
    mf.set(qn('m:val'),'Latin Modern Math')
    upd=doc.settings.element.find(qn('w:updateFields'))
    if upd is None:upd=OxmlElement('w:updateFields');doc.settings.element.append(upd)
    upd.set(qn('w:val'),'true')
    doc.core_properties.title=TITLE;doc.core_properties.subject=SUBTITLE;doc.core_properties.author='王德生'
    doc.core_properties.keywords='数学 人工智能 SDE 典范发生 工具封装'


def bookmark(p,name,n):
    a=OxmlElement('w:bookmarkStart');a.set(qn('w:id'),str(n));a.set(qn('w:name'),name)
    b=OxmlElement('w:bookmarkEnd');b.set(qn('w:id'),str(n));p._p.insert(0,a);p._p.append(b)

def toc_link(p,text,anchor):
    h=OxmlElement('w:hyperlink');h.set(qn('w:anchor'),anchor)
    r=OxmlElement('w:r');rp=OxmlElement('w:rPr');c=OxmlElement('w:color');c.set(qn('w:val'),NAVY);rp.append(c);r.append(rp)
    t=OxmlElement('w:t');t.text=text;r.append(t);h.append(r);p._p.append(h)

def after(p,text='',style=None):
    el=OxmlElement('w:p');p._p.addnext(el);q=Paragraph(el,p._parent)
    if style:q.style=style
    if text:q.add_run(text)
    return q

def normalize(s):
    # Handle only outside already-marked math to avoid double dollar delimiters.
    parts=re.split(r'(\$\$.*?\$\$|\$[^$]*\$)',s,flags=re.S)
    for i in range(0,len(parts),2):
        t=parts[i]
        t=re.sub(r'([SDE])\s*[＝=]\s*([FGH])\(\s*([SDE]),\s*([SDE])\s*\)',lambda m:f'${m[1]}={m[2]}({m[3]},{m[4]})$',t)
        parts[i]=t
    return ''.join(parts)

def bibliography_entries():
    entries=[];seen=set();source_counts={}
    for p in sorted((ROOT/'research').glob('bibliography_*.md')):
        text=p.read_text();local=[]
        # Numbered and Hxx-xx bullet bibliographies use line-led records.
        start=re.compile(r'^\s*(?:[-*]\s*)?(?:\d+[.)]|H\d{2}-\d{2}\.)\s+')
        lines=text.splitlines();numbered=any(start.match(l) for l in lines)
        if numbered:
            current=[]
            for line in lines:
                if line.lstrip().startswith('#'):continue
                if start.match(line):
                    if current:local.append(' '.join(current))
                    current=[start.sub('',line).strip()]
                elif current and line.strip():current.append(line.strip())
            if current:local.append(' '.join(current))
        else:
            for para in re.split(r'\n\s*\n',text):
                para=' '.join(l.strip() for l in para.splitlines() if not l.lstrip().startswith('#')).strip()
                if 'https://' in para or 'http://' in para:
                    if re.match(r'^(以上|以下|说明|网页核对|核对日期|本编|访问日期)',para):continue
                    local.append(para)
        count=0
        for para in local:
            para=' '.join(para.split()).strip()
            if not para:continue
            urls=re.findall(r'https?://[^\s）)]+',para)
            key=urls[0].rstrip('.,。；;') if urls else para
            if key in seen:continue
            seen.add(key);entries.append(para.replace('网页未核定原始发表年月','无日期'));count+=1
        source_counts[p.name]={'parsed':len(local),'retained':count}
    (QA/'bibliography_parse.json').write_text(json.dumps(source_counts,ensure_ascii=False,indent=2))
    return entries

def add_background_image(doc,p,path,width=Mm(190),height=Mm(250)):
    # Add the image to the final document part, so its rId cannot collide in a merge.
    run=p.add_run();inline=run.add_picture(str(path),width=width,height=height)._inline
    anchor=OxmlElement('wp:anchor')
    for k,v in [('distT','0'),('distB','0'),('distL','0'),('distR','0'),('simplePos','0'),('relativeHeight','0'),('behindDoc','1'),('locked','0'),('layoutInCell','1'),('allowOverlap','1')]:anchor.set(k,v)
    simp=OxmlElement('wp:simplePos');simp.set('x','0');simp.set('y','0');anchor.append(simp)
    for axis in ['H','V']:
        pos=OxmlElement('wp:position'+axis);pos.set('relativeFrom','page');off=OxmlElement('wp:posOffset');off.text='0';pos.append(off);anchor.append(pos)
    for name in ['extent','effectExtent']:
        el=inline.find(qn('wp:'+name))
        if el is not None:anchor.append(copy.deepcopy(el))
    anchor.append(OxmlElement('wp:wrapNone'))
    for name in ['docPr','cNvGraphicFramePr']:
        el=inline.find(qn('wp:'+name))
        if el is not None:anchor.append(copy.deepcopy(el))
    anchor.append(copy.deepcopy(inline.find(qn('a:graphic'))))
    inline.getparent().replace(inline,anchor)
    return anchor

def make_cover(doc,p):
    p.clear();p.style='Cover Kicker';p.paragraph_format.space_before=Pt(24);p.paragraph_format.space_after=Pt(8)
    p.add_run('面对AI的冲击，')
    art=ROOT/'figures'/'cover-art.png'
    if art.exists():add_background_image(doc,p,art)
    q=after(p,'数学家\n走向何处？','Cover Main');q.paragraph_format.line_spacing=Pt(40);q.paragraph_format.space_after=Pt(14)
    q=after(q,'从常规解题到人—AI复合体的\n多元数学发生','Cover Sub');q.paragraph_format.line_spacing=Pt(20);q.paragraph_format.space_after=Pt(10)
    q=after(q,'王德生 著','Cover Author');q.paragraph_format.space_before=Pt(6)
    q=after(q,'德麦国际出版社\nDemai International Press','Book Metadata');q.paragraph_format.space_before=Pt(306);q.paragraph_format.line_spacing=Pt(15);q.paragraph_format.space_after=Pt(0);q.alignment=WD_ALIGN_PARAGRAPH.RIGHT
    for r in q.runs:set_font(r,10,False,NAVY,SANS)

def add_part_page(head,idx,intros):
    pn=list(PARTS).index(idx)+1
    a=head.insert_paragraph_before(f'{pn:02d}',style='Part Number');a.paragraph_format.page_break_before=True;a.paragraph_format.space_before=Pt(68);a.paragraph_format.space_after=Pt(5);a.alignment=WD_ALIGN_PARAGRAPH.CENTER
    label,title=PARTS[idx].split(' ',1)
    a=head.insert_paragraph_before(label,style='Part Label');a.alignment=WD_ALIGN_PARAGRAPH.CENTER;a.paragraph_format.space_after=Pt(13)
    a=head.insert_paragraph_before(title,style='Part Title');a.alignment=WD_ALIGN_PARAGRAPH.CENTER;a.paragraph_format.space_after=Pt(20)
    bookmark(a,f'part_{idx:02}',3000+idx)
    # A short line is implemented as a centered small paragraph border.
    a=head.insert_paragraph_before('',style='Part Label');a.paragraph_format.left_indent=Mm(56);a.paragraph_format.right_indent=Mm(56);a.paragraph_format.space_after=Pt(27);border(a,size=5,space=1)
    intro=intros.get(str(idx),'')
    if isinstance(intro,dict):intro=intro.get('intro',intro.get('text',''))
    if intro:
        for text in str(intro).split('\n\n'):
            a=head.insert_paragraph_before(text,style='Part Intro');a.paragraph_format.left_indent=Mm(8);a.paragraph_format.right_indent=Mm(8);a.paragraph_format.line_spacing=Pt(21);a.paragraph_format.space_after=Pt(10)


def first_sentence(source):
    for para in re.split(r'\n\s*\n',source):
        if not para.strip() or para.startswith(('#','|','```','![')) or '$$' in para:continue
        t=re.sub(r'\*\*|\*|`','',para).strip()
        t=re.sub(r'\$[^$]*\$','',t)
        if len(t)>15:
            sentence=re.split(r'(?<=[。！？])',t)[0]
            if 12<len(sentence)<=120:return sentence
    return ''

def style_tables(doc):
    for table in doc.tables:
        # Use existing Word styles explicitly; an undefined Pandoc 'Table'/'Compact'
        # pair can be imported incorrectly by LibreOffice and detach text from cells.
        table.style='Table Grid';table.alignment=WD_TABLE_ALIGNMENT.CENTER;table.autofit=False
        cols=len(table.columns);total=Mm(154)
        proportions={2:[.30,.70],3:[.23,.44,.33],4:[.20,.31,.13,.36],5:[.15,.25,.2,.2,.2]}.get(cols,[1/cols]*cols)
        for c,pr in zip(table.columns,proportions):c.width=int(total*pr)
        for ri,row in enumerate(table.rows):
            trpr=row._tr.get_or_add_trPr()
            if trpr.find(qn('w:cantSplit')) is None:trpr.append(OxmlElement('w:cantSplit'))
            if ri==0:
                if trpr.find(qn('w:tblHeader')) is None:
                    repeat=OxmlElement('w:tblHeader');repeat.set(qn('w:val'),'true');trpr.append(repeat)
            for ci,cell in enumerate(row.cells):
                cell.width=int(total*proportions[ci]);cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
                pr=cell._tc.get_or_add_tcPr();mar=OxmlElement('w:tcMar')
                for side,sz in [('top',90),('bottom',90),('left',100),('right',100)]:
                    el=OxmlElement('w:'+side);el.set(qn('w:w'),str(sz));el.set(qn('w:type'),'dxa');mar.append(el)
                pr.append(mar);sh=OxmlElement('w:shd');sh.set(qn('w:fill'),NAVY if ri==0 else (PAPER if ri%2==0 else 'FFFFFF'));pr.append(sh)
                for p in cell.paragraphs:
                    p.style='Normal';p.alignment=WD_ALIGN_PARAGRAPH.LEFT;p.paragraph_format.keep_with_next=False
                    p.paragraph_format.first_line_indent=Pt(0);p.paragraph_format.line_spacing=Pt(15);p.paragraph_format.line_spacing_rule=WD_LINE_SPACING.AT_LEAST;p.paragraph_format.space_after=Pt(3);p.paragraph_format.space_before=Pt(0)
                    for r in p.runs:set_font(r,9.3,ri==0,'FFFFFF' if ri==0 else INK,SANS)
            borders=table._tbl.tblPr.find(qn('w:tblBorders'))
            if borders is None:
                borders=OxmlElement('w:tblBorders');table._tbl.tblPr.append(borders)
                for side in ['top','bottom','left','right','insideH','insideV']:
                    e=OxmlElement('w:'+side);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'D9D9D9');borders.append(e)

def style_code(doc):
    for p in doc.paragraphs:
        sid=p._p.find('./'+qn('w:pPr')+'/'+qn('w:pStyle'))
        if sid is not None and sid.get(qn('w:val')) in {'SourceCode','Code'}:
            p.style='Code';p.alignment=WD_ALIGN_PARAGRAPH.LEFT
            p.paragraph_format.first_line_indent=Pt(0);p.paragraph_format.line_spacing=Pt(15)
            p.paragraph_format.line_spacing_rule=WD_LINE_SPACING.AT_LEAST
            p.paragraph_format.keep_together=True;p.paragraph_format.space_before=Pt(6);p.paragraph_format.space_after=Pt(10)
            for r in p.runs:
                rpr=r._r.get_or_add_rPr();rs=rpr.find(qn('w:rStyle'))
                if rs is not None:rpr.remove(rs)
                set_font(r,9,False,INK,'Liberation Mono');r.font.italic=False;r.font.underline=False

def headers(doc):
    doc.settings.odd_and_even_pages_header_footer=True
    for sec in doc.sections:
        sec.different_first_page_header_footer=True
        for kind,align in [('header',WD_ALIGN_PARAGRAPH.RIGHT),('even_page_header',WD_ALIGN_PARAGRAPH.LEFT)]:
            h=getattr(sec,kind);p=h.paragraphs[0];p.clear();p.alignment=align
            r=p.add_run('面对AI的冲击，数学家走向何处？');set_font(r,7.5,False,GRAY,SANS)
            p.paragraph_format.first_line_indent=Pt(0);p.paragraph_format.space_after=Pt(0);p.paragraph_format.line_spacing=Pt(10)
            border(p,color='DCD6C9',size=3,space=4)
        for kind,align in [('footer',WD_ALIGN_PARAGRAPH.RIGHT),('even_page_footer',WD_ALIGN_PARAGRAPH.LEFT)]:
            p=getattr(sec,kind).paragraphs[0];p.clear();p.alignment=align;p.paragraph_format.first_line_indent=Pt(0)
            fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');r=OxmlElement('w:r');rp=OxmlElement('w:rPr');size=OxmlElement('w:sz');size.set(qn('w:val'),'16');rp.append(size);col=OxmlElement('w:color');col.set(qn('w:val'),GRAY);rp.append(col);r.append(rp);t=OxmlElement('w:t');t.text='1';r.append(t);fld.append(r);p._p.append(fld)


def add_backcover(doc):
    path=ROOT/'frontmatter'/'backcover.md'
    if not path.exists():return
    sec=doc.add_section(WD_SECTION_START.NEW_PAGE);sec.different_first_page_header_footer=True
    for name in ['header','even_page_header','first_page_header','footer','even_page_footer','first_page_footer']:
        h=getattr(sec,name);h.is_linked_to_previous=False
        for p in h.paragraphs:p.clear()
    bg=ROOT/'figures'/'backdrop-navy.png'
    if not bg.exists():Image.new('RGB',(4,4),'#'+NAVY).save(bg)
    paras=[x.strip() for x in re.split(r'\n\s*\n',path.read_text()) if x.strip()]
    p=doc.add_paragraph(paras[0].lstrip('# ').strip(),style='Back Title');p.paragraph_format.space_before=Pt(35);p.paragraph_format.space_after=Pt(24)
    add_background_image(doc,p,bg)
    for text in paras[1:]:
        q=doc.add_paragraph(text,style='Back Text');q.paragraph_format.line_spacing=Pt(21);q.paragraph_format.space_after=Pt(15)
        if text in ['王德生 著','德麦国际出版社','DEMAI INTERNATIONAL PRESS']:
            for r in q.runs:set_font(r,10.5,False,PALE,SANS)


def main():
    partial='--partial' in sys.argv;sample='--sample' in sys.argv
    paths=[ROOT/'chapters'/f'{i:02}.md' for i in range(39)]
    if not partial and any(not p.exists() for p in paths):raise SystemExit('Missing chapters')
    paths=[p for p in paths if p.exists()]
    if sample:paths=[p for p in paths if p.stem=='26']
    entries=bibliography_entries();records=[];sources={};front_records=[]
    texts=['[[COVER_PLACEHOLDER]]']
    for ident,fallback in FRONTS:
        p=ROOT/'frontmatter'/f'{ident}.md'
        if not p.exists():continue
        s=normalize(p.read_text());title=re.search(r'^#\s+(.+)',s,re.M).group(1)
        front_records.append({'id':ident,'title':title,'anchor':'front_'+ident});texts.append(s)
    texts.append('# 目录\n\n[[TOC_PLACEHOLDER]]')
    for p in paths:
        s=normalize(p.read_text());idx=int(p.stem);sources[idx]=s
        title=re.search(r'^#\s+(.+)',s,re.M).group(1)
        records.append({'index':idx,'title':title,'anchor':f'chapter_{idx:02}'})
        if idx==26:
            s=s.replace('## 三、为什么必须区分三种同一性','![图26-1 有限记录位置上的单伞与双峰剖面。柱高严格对应正文算例；不表示连续位置上的实测结果。]('+str(ROOT/'figures'/'figure26_1.png')+'){width=5.85in}\n\n## 三、为什么必须区分三种同一性')
            s=s.replace('## 六、让候选模型与既有理论正面相遇','![图26-2 衰减系数为二分之一时，两种输入次序得到相同总量、不同空间分布。]('+str(ROOT/'figures'/'figure26_2.png')+'){width=5.85in}\n\n## 六、让候选模型与既有理论正面相遇')
        texts.append(s)
    used_entries=entries[:8] if sample else entries
    if used_entries:
        texts.append('# 参考文献与资料\n\n'+'\n\n'.join(f'［{i+1}］ {x}' for i,x in enumerate(used_entries)))
        records.append({'index':39,'title':'参考文献与资料','anchor':'chapter_39'})
    if not partial:
        texts.append('# 主题索引\n\n本索引列出各主题的重点论述起页，供查阅相关章节。\n\n[[INDEX_PLACEHOLDER]]')
        records.append({'index':40,'title':'主题索引','anchor':'chapter_40'})
    md=OUT/('排版样稿正文.md' if sample else '完整正文.md');md.write_text('\n\n'.join(texts))
    ref=Document();setup(ref);ref.save(OUT/'reference.docx')
    raw=OUT/('sample_body.docx' if sample else 'body.docx')
    subprocess.run(['pandoc',str(md),'-f','markdown+tex_math_dollars+autolink_bare_uris','--standalone','--reference-doc',str(OUT/'reference.docx'),'-o',str(raw)],check=True)
    doc=Document(raw);setup(doc)
    bytitle={r['title']:r for r in records};frontbytitle={r['title']:r for r in front_records}
    introfile=ROOT/'frontmatter'/'part_intros.json';intros=json.loads(introfile.read_text()) if introfile.exists() else {}
    found=[]
    for p in list(doc.paragraphs):
        if p.style.name!='Heading 1':continue
        original=p.text
        if original in frontbytitle:
            rec=frontbytitle[original];p.style='Front Title';p.paragraph_format.page_break_before=True;p.paragraph_format.space_before=Pt(16);p.paragraph_format.space_after=Pt(24)
            bookmark(p,rec['anchor'],4000+front_records.index(rec));continue
        if original=='目录':
            p.style='Front Title';p.paragraph_format.page_break_before=True;p.paragraph_format.space_after=Pt(20);bookmark(p,'contents',4999);continue
        rec=bytitle.get(original)
        if rec is None:continue
        idx=rec['index'];found.append(idx);bookmark(p,rec['anchor'],1000+idx)
        p.paragraph_format.page_break_before=True;p.paragraph_format.space_before=Pt(13);p.paragraph_format.space_after=Pt(15)
        if idx in PARTS:add_part_page(p,idx,intros)
        match=re.match(r'^(第[一二三四五六七八九十百0-9]+章)[\s\u3000]+(.+)$',original)
        if match:
            # Retain all title characters and heading identity; only line-break the label.
            bookmarks=[copy.deepcopy(x) for x in p._p if x.tag in {qn('w:bookmarkStart'),qn('w:bookmarkEnd')}]
            p.clear();r=p.add_run(match[1]);set_font(r,9.5,True,GOLD,SANS);r.add_break()
            r=p.add_run(match[2]);set_font(r,18,True,NAVY,SERIF)
            for b in bookmarks:p._p.append(b)
            border(p,color=GOLD,size=4,space=10)
        if 1<=idx<=35:
            excerpt=first_sentence(sources[idx])
            if excerpt:
                q=after(p,'章首摘句　'+excerpt,'Chapter Quote');shade(q);border(q,'left',GOLD,14,7)
    if set(found)!={r['index'] for r in records}:raise RuntimeError(('Heading mismatch',found,records))
    for p in list(doc.paragraphs):
        if p.text=='[[COVER_PLACEHOLDER]]':make_cover(doc,p)
        elif p.text=='[[TOC_PLACEHOLDER]]':
            for fr in front_records:
                q=p.insert_paragraph_before(style='TOC Entry');toc_link(q,fr['title'],fr['anchor']);q.add_run('\t');q.add_run('000')
                bookmark(q,'toc_'+fr['anchor'],4500+front_records.index(fr))
            for rec in records:
                if rec['index'] in PARTS:
                    q=p.insert_paragraph_before(PARTS[rec['index']],style='TOC Entry');q.paragraph_format.space_before=Pt(11)
                    for r in q.runs:set_font(r,10.2,True,GOLD,SANS)
                q=p.insert_paragraph_before(style='TOC Entry');toc_link(q,rec['title'],rec['anchor']);q.add_run('\t');q.add_run('000')
                bookmark(q,'toc_'+rec['anchor'],2000+rec['index'])
            p._element.getparent().remove(p._element)
    for p in doc.paragraphs:
        if p.style.name in ['Normal','Body Text','First Paragraph']:
            p.paragraph_format.widow_control=True
            if p._p.find('.//'+qn('m:oMath')) is not None:
                p.paragraph_format.line_spacing=Pt(21.5);p.paragraph_format.line_spacing_rule=WD_LINE_SPACING.AT_LEAST
                if p._p.find('.//'+qn('m:oMathPara')) is not None:p.paragraph_format.first_line_indent=Pt(0);p.alignment=WD_ALIGN_PARAGRAPH.CENTER
        if p.style.name=='Heading 2':border(p,'left',GOLD,10,7)
        if re.match(r'^［\d+］',p.text):p.style='References'
        if p._p.find('.//'+qn('wp:inline')) is not None:
            # Pandoc may reference CaptionedFigure without defining it in a custom reference.
            # Explicit minimum line height prevents LibreOffice from clipping an inline drawing.
            p.style='Normal';p.paragraph_format.first_line_indent=Pt(0);p.alignment=WD_ALIGN_PARAGRAPH.CENTER
            extent=p._p.find('.//'+qn('wp:extent'));height=int(extent.get('cy'))/12700
            p.paragraph_format.line_spacing=Pt(height+3);p.paragraph_format.line_spacing_rule=WD_LINE_SPACING.AT_LEAST
            p.paragraph_format.space_before=Pt(7);p.paragraph_format.space_after=Pt(5);p.paragraph_format.keep_with_next=True
        sid=p._p.find('./'+qn('w:pPr')+'/'+qn('w:pStyle'))
        if 'Caption' in p.style.name or (sid is not None and sid.get(qn('w:val'))=='ImageCaption'):
            p.style='Caption'
            p.paragraph_format.first_line_indent=Pt(0);p.paragraph_format.line_spacing=1.2;p.alignment=WD_ALIGN_PARAGRAPH.CENTER
            for r in p.runs:set_font(r,9,False,GRAY,SANS)
    style_tables(doc);style_code(doc);headers(doc);add_backcover(doc)
    result=OUT/('数学家的未来_排版样稿.docx' if partial else '面对AI的冲击_数学家走向何处_全稿_v1.0.docx');doc.save(result)
    navname='sample_book_navigation.json' if sample else 'book_navigation.json'
    (QA/navname).write_text(json.dumps(records,ensure_ascii=False,indent=2))
    (QA/'front_navigation.json').write_text(json.dumps(front_records,ensure_ascii=False,indent=2))
    (QA/('sample_field_title_map.json' if sample else 'field_title_map.json')).write_text(json.dumps({'chapters':records,'frontmatter':front_records,'parts':PARTS,'toc_field':'PAGE','chapter_page_materialization':'finalize_navigation.py maps level-1 PDF bookmarks after whitespace removal'},ensure_ascii=False,indent=2))
    print(json.dumps({'file':str(result),'chapters':len(paths),'bibliography_total':len(entries),'bibliography_used':len(used_entries),'frontmatter':len(front_records),'sample':sample},ensure_ascii=False))

if __name__=='__main__':main()
