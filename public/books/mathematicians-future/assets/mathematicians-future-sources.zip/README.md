# 面对AI的冲击，数学家走向何处？

王德生著。数字阅读版 v1.0，2026年10月。副标题：从常规解题到人—AI复合体的多元数学发生。

本包保存七编三十五章、导论、结语与两篇附录的完整文本，以及前言、导读、书目、数学代码和制作文件。正文为213,068个汉字；统计排除标题、程序、参考文献与编辑辅文。所有章节均达到原分配篇幅，第二附录为追加内容。

在线入口：https://sdeuniverses.com/books/mathematicians-future/

## 阅读与复现

`完整正文.md`为连续文本，`chapters/00.md`至`38.md`为分章底本。Word保留原生数学公式；阅读PDF为190×250毫米，印刷PDF为170×240毫米，两者保留同一页码。

`code/README.md`说明有限伞模型。进入code目录后，以Python 3运行：

```bash
python umbrella_model.py
python -m unittest -v test_umbrella_model.py
```

程序使用标准库和精确有理数；11项测试已实际运行通过。测试覆盖有限算例、二维观察闭合、饱和运算和同维线性基线；一般性结论以第六编的证明为准，合成数据不是人体实验。

## 文稿与制作材料

`frontmatter/`保存前后辅文；`research/`保存分编书目与核验记录；`figures/`保存专属封面艺术、排版封面及两幅精确算例图；`qa/`保存内部交叉审稿、正文计数、完整性与版式检查记录。内部审读不等于外部同行评议。

根目录脚本保存Word/PDF装配流程，需要Python的python-docx、PyMuPDF、Pillow、matplotlib及Pandoc，并使用Noto Serif CJK SC、Noto Sans CJK SC和Latin Modern Math字体。Word转PDF的具体命令依运行环境而定，最终页码需在渲染后重新核定。

`site/`保存新增书页和生成脚本，绝不要求用旧catalog覆盖生产站。再次发布时须先读取网站最新书目，生成最小增量，并保持其他专著不变。下载资产独立交付；配套包不重复嵌套自身。

版权与协作方式见书中《出版与版本说明》。封面使用图像生成创作，书名和出版信息以真实排版文字叠印；数学图依据正文数值绘制。
