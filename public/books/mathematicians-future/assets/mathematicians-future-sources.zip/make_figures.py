from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

root=Path(__file__).resolve().parent
out=root/'figures';out.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'Noto Serif CJK SC','font.size':12,'axes.unicode_minus':False,'axes.spines.top':False,'axes.spines.right':False,'axes.titlesize':13})
colors=['#213C54','#966D39']
fig,axs=plt.subplots(1,2,figsize=(9,3.35),layout='constrained')
for ax,y,col,title in zip(axs,[[.5,1,.5],[1,0,1]],colors,['单伞：中心1，范围2，强度1','两个端点单伞相加']):
    ax.bar([0,1,2],y,width=.48,color=col)
    ax.set(xticks=[0,1,2],ylim=(0,1.24),xlabel='记录位置',ylabel='影响强度',title=title)
    ax.set_yticks([0,.5,1]);ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True)
    for x,v in enumerate(y):ax.text(x,v+.04,f'{v:g}',ha='center',fontsize=11)
fig.savefig(out/'figure26_1.png',dpi=220);plt.close(fig)
fig,axs=plt.subplots(1,2,figsize=(9,3.35),layout='constrained')
for ax,y,col,title in zip(axs,[[.5,0,1],[1,0,.5]],colors,['先左后右：当前总量1.5','先右后左：当前总量1.5']):
    ax.bar([0,1,2],y,width=.48,color=col)
    ax.set(xticks=[0,1,2],ylim=(0,1.24),xlabel='记录位置',ylabel='当前影响强度',title=title)
    ax.set_yticks([0,.5,1]);ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True)
    for x,v in enumerate(y):ax.text(x,v+.04,f'{v:g}',ha='center',fontsize=11)
fig.savefig(out/'figure26_2.png',dpi=220);plt.close(fig)
print('2 exact synthetic profile figures written')
