from pathlib import Path
import sys,json,re
from docx import Document
from docx.oxml.ns import qn
import fitz

R=Path(__file__).resolve().parent
F=R/'output'/'面对AI的冲击_数学家走向何处_全稿_v1.0.docx'
pdf=fitz.open(sys.argv[1]);doc=Document(F)
nav=json.loads((R/'qa'/'book_navigation.json').read_text())
front_nav=json.loads((R/'qa'/'front_navigation.json').read_text())
def clean(x):return re.sub(r'\s+','',x)
toc={clean(title):page for level,title,page in pdf.get_toc() if level==1}
pages={rec['index']:toc[clean(rec['title'])] for rec in nav}
front_pages={rec['id']:toc[clean(rec['title'])] for rec in front_nav}
for p in doc.paragraphs:
    for b in p._p.findall(qn('w:bookmarkStart')):
        n=b.get(qn('w:name'),'')
        if n.startswith('toc_chapter_'):
            idx=int(n.rsplit('_',1)[1]);p.runs[-1].text=str(pages[idx])
        elif n.startswith('toc_front_'):
            ident=n[len('toc_front_'):];p.runs[-1].text=str(front_pages[ident])
topics={
'能力与智慧的封装':[0,2,13], '同轨内卷与价值转移':[11,15,36], '复合研究能力':[4,32],
'研究 职业 人生三种升级':[5,31,35], '印刷与出版职业':[6], '纺织机械与劳动控制':[6],
'蒸汽 铁路与专业系统':[7], '汽车 电气化与配套条件':[8], '制冷 集装箱与新需求':[9],
'计算机 互联网与知识劳动':[10], '新任务与新职业':[12,14,33], '库恩与常规科学':[16,17],
'典范更替与多元并存':[18,19], '模型创新 研究纲领 典范候选':[19,20], 'SDE三方程':[21],
'特征纠缠与场模态':[21,24], '数学对象的发生':[22,23], '参数 剖面 观测三种同一性':[23,26],
'视觉 触觉 听觉入口':[24], '我的数学与我们的数学':[25], '伞模型与范围性影响':[26,27],
'运算闭合与顺序效应':[27,28], '观测闭合与状态扩充':[28,29], '分化 重组 升维':[29],
'研究作品与可接续性':[30,31], 'AI参与博士培养':[34], '研究评价与共同体':[35],
'多元科学发生':[37], '物理 化学 生物的检验约束':[37],
'交通多元化与理念多元化':[38], '对库恩的发生学拓展':[18,38],
'典范作为研究对象':[29,38], 'SDE的主体 对象 环境共同发生':[21,38]}
for p in list(doc.paragraphs):
    if p.text=='[[INDEX_PLACEHOLDER]]':
        for topic,ids in topics.items():
            p.insert_paragraph_before(topic+'　'+ '、'.join(str(pages[i]) for i in ids),style='References')
        p._element.getparent().remove(p._element)
doc.save(F)
(R/'qa'/'verified_page_map.json').write_text(json.dumps(pages,ensure_ascii=False,indent=2))
(R/'qa'/'verified_front_page_map.json').write_text(json.dumps(front_pages,ensure_ascii=False,indent=2))
print(json.dumps({'chapter_page_entries':len(pages),'subject_entries':len(topics),'body_pages_before_index_expansion':pdf.page_count},ensure_ascii=False))
