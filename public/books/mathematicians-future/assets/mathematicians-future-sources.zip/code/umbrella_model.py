"""A finite nonnegative-profile laboratory; no novelty or empirical claim.

All built-in examples use Fraction so the reported identities are exact.
Run: python umbrella_model.py
Tests: python -m unittest -v test_umbrella_model.py (from this directory).
"""
from fractions import Fraction as F
import json


def _vec(xs):
    return tuple(F(x) for x in xs)


def _nonnegative(xs):
    xs = _vec(xs)
    if not xs or any(x < 0 for x in xs):
        raise ValueError("A profile must be nonempty and nonnegative")
    return xs


def umbrella(points, center, radius, amplitude):
    """Tent profile on a finite subset of the real line with ordinary metric."""
    points, center, radius, amplitude = _vec(points), F(center), F(radius), F(amplitude)
    if not points or len(set(points)) != len(points) or center not in points:
        raise ValueError("Distinct points and a center in the domain are required")
    if radius < 0 or amplitude < 0:
        raise ValueError("Radius and amplitude must be nonnegative")
    if radius == 0:
        return tuple(amplitude if x == center else F(0) for x in points)
    return tuple(amplitude * max(F(0), F(1) - abs(x-center)/radius) for x in points)


def add(u, v):
    u, v = _nonnegative(u), _nonnegative(v)
    if len(u) != len(v):
        raise ValueError("Profile sizes differ")
    return tuple(x+y for x, y in zip(u, v))


def maximum(u, v):
    u, v = _nonnegative(u), _nonnegative(v)
    if len(u) != len(v):
        raise ValueError("Profile sizes differ")
    return tuple(max(x, y) for x, y in zip(u, v))


def saturating_add(u, v, cap=1):
    cap = F(cap)
    if cap <= 0:
        raise ValueError("Cap must be positive")
    return tuple(min(cap, x) for x in add(u, v))


def normalize(u):
    u = _nonnegative(u)
    total = sum(u)
    if total == 0:
        raise ValueError("The zero profile cannot be normalized")
    return tuple(x/total for x in u)


def normalized_add(u, v):
    return normalize(add(u, v))


def matvec(A, u):
    u = _vec(u)
    A = tuple(_vec(row) for row in A)
    if not A or any(len(row) != len(u) for row in A):
        raise ValueError("Matrix and vector dimensions differ")
    return tuple(sum(a*x for a, x in zip(row, u)) for row in A)


def max_row_sum(K):
    K = tuple(_vec(row) for row in K)
    n = len(K)
    if n == 0 or any(len(row) != n for row in K) or any(x < 0 for row in K for x in row):
        raise ValueError("K must be square, nonempty, and nonnegative")
    return max(sum(row) for row in K)


def update(K, u, v):
    u, v = _nonnegative(u), _nonnegative(v)
    max_row_sum(K)
    if len(K) != len(u):
        raise ValueError("State dimension differs from K")
    return add(matvec(K, u), v)


def decay_update(u, v, decay=F(1, 2)):
    decay = F(decay)
    if not 0 <= decay < 1:
        raise ValueError("Decay must lie in [0,1)")
    return add(tuple(decay*x for x in _nonnegative(u)), v)


def run(K, inputs, initial):
    states = [_nonnegative(initial)]
    for v in inputs:
        states.append(update(K, states[-1], v))
    return states


def support(u):
    return {i for i, x in enumerate(_nonnegative(u)) if x > 0}


def supnorm(u):
    return max(abs(x) for x in _vec(u))


def difference(u, v):
    u, v = _vec(u), _vec(v)
    if len(u) != len(v):
        raise ValueError("Vector sizes differ")
    return tuple(x-y for x, y in zip(u, v))


def common_decay_trace(inputs, decay=F(1, 2)):
    inputs = list(inputs)
    if not inputs:
        raise ValueError("At least one input is required")
    u = tuple(F(0) for _ in inputs[0])
    for v in inputs:
        u = decay_update(u, v, decay)
    return u


def ordinary_vector_history(inputs, decay=F(1, 2)):
    """Same-dimensional standard linear-state baseline via closed-form sum.

    This is mathematically equivalent to the umbrella linear branch, not a
    competing weak baseline. The equality is intentional and reported.
    """
    inputs = [_nonnegative(v) for v in inputs]
    decay = F(decay)
    if not inputs or not 0 <= decay < 1:
        raise ValueError("Need inputs and decay in [0,1)")
    n = len(inputs[0])
    if any(len(v) != n for v in inputs):
        raise ValueError("Input sizes differ")
    return tuple(sum(decay**(len(inputs)-1-j)*v[i] for j,v in enumerate(inputs)) for i in range(n))


K = ((F(1,2), F(1,4), F(0)),
     (F(1,4), F(1,4), F(1,4)),
     (F(0), F(1,4), F(1,2)))


def demo():
    zero, e0, e1, e2 = (F(0),)*3, (F(1),F(0),F(0)), (F(0),F(1),F(0)), (F(0),F(0),F(1))
    wide = umbrella((0,1,2), 1, 2, 1)
    left_then_right = common_decay_trace((e0,e2))
    right_then_left = common_decay_trace((e2,e0))
    propagated = run(K, (zero,zero), e0)
    Pmiddle = ((0,1,0),)
    closure_counterexample = {
        "same_initial_middle": [matvec(Pmiddle,e0),matvec(Pmiddle,zero)],
        "different_next_middle": [matvec(Pmiddle,matvec(K,e0)),matvec(Pmiddle,matvec(K,zero))],
    }
    midpoint_prediction = F(3,4)
    scalar_mse = sum((x[0]-midpoint_prediction)**2 for x in (left_then_right,right_then_left))/2
    result = {
        "wide_umbrella": wide,
        "two_poles": add(e0,e2),
        "left_then_right": left_then_right,
        "right_then_left": right_then_left,
        "propagation": propagated,
        "max_row_sum": max_row_sum(K),
        "observation_nonclosure": closure_counterexample,
        "normalized_left_bracket": normalized_add(normalized_add(e0,e1),e2),
        "normalized_right_bracket": normalized_add(e0,normalized_add(e1,e2)),
        "synthetic_pair_total": [sum(left_then_right),sum(right_then_left)],
        "synthetic_pair_best_total_only_left_prediction": midpoint_prediction,
        "synthetic_pair_best_total_only_mse": scalar_mse,
        "synthetic_pair_full_state_mse": F(0),
        "standard_same_dimension_linear_states": [ordinary_vector_history((e0,e2)),ordinary_vector_history((e2,e0))],
        "standard_same_dimension_linear_mse": F(0),
    }
    return result


def _jsonable(x):
    if isinstance(x,F):
        return str(x)
    if isinstance(x,dict):
        return {k:_jsonable(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)):
        return [_jsonable(v) for v in x]
    return x


if __name__ == "__main__":
    print(json.dumps(_jsonable(demo()), ensure_ascii=False, indent=2))
