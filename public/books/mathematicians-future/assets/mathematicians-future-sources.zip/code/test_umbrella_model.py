"""Exact arithmetic tests of counterexamples and invariants in chapters 26--30."""
import itertools
import unittest
from fractions import Fraction as F
from umbrella_model import *


class UmbrellaTests(unittest.TestCase):
    def setUp(self):
        self.zero = (F(0),)*3
        self.e = tuple(tuple(F(i==j) for i in range(3)) for j in range(3))

    def test_radius_zero_and_parameter_nonidentifiability(self):
        self.assertEqual(umbrella((0,1,2),0,0,1), umbrella((0,1,2),0,F(1,2),1))
        self.assertEqual(umbrella((0,1,2),1,2,1),(F(1,2),F(1),F(1,2)))

    def test_update_order_exact_formula(self):
        for u,v,w in itertools.product(self.e,repeat=3):
            a=decay_update(decay_update(u,v),w)
            b=decay_update(decay_update(u,w),v)
            self.assertEqual(difference(a,b),tuple(F(1,2)*(x-y) for x,y in zip(w,v)))

    def test_nonclosure_and_positive_closed_observation(self):
        P=((0,1,0),)
        self.assertEqual(matvec(P,self.e[0]),matvec(P,self.zero))
        self.assertNotEqual(matvec(P,matvec(K,self.e[0])),matvec(P,matvec(K,self.zero)))
        for u in itertools.product((0,F(1,2),1),repeat=3):
            self.assertEqual(sum(matvec(K,u)),F(3,4)*sum(u))

    def test_support_paths_and_exact_trace(self):
        states=run(K,[self.zero,self.zero],self.e[0])
        self.assertEqual([support(u) for u in states],[{0},{0,1},{0,1,2}])
        self.assertEqual(states[2],(F(5,16),F(3,16),F(1,16)))

    def test_two_dimensional_observation_closure_with_inputs(self):
        Q=((0,1,0),(1,1,1))
        L=((0,F(1,4)),(0,F(3,4)))
        for u in itertools.product((0,F(1,2),1),repeat=3):
            for v in self.e:
                lhs=matvec(Q,update(K,u,v))
                rhs=add(matvec(L,matvec(Q,u)),matvec(Q,v))
                self.assertEqual(lhs,rhs)

    def test_standard_linear_baseline_equals_umbrella_linear_branch(self):
        for inputs in itertools.product(self.e,repeat=4):
            self.assertEqual(common_decay_trace(inputs),ordinary_vector_history(inputs))

    def test_saturation_combines_but_does_not_commute_with_decay(self):
        cap=F(1)
        u=(F(2),)
        observation_after_decay=tuple(min(cap,F(1,2)*x) for x in u)
        decay_after_observation=tuple(F(1,2)*min(cap,x) for x in u)
        self.assertEqual(observation_after_decay,(F(1),))
        self.assertEqual(decay_after_observation,(F(1,2),))

    def test_stability_bound_on_grid(self):
        rho=max_row_sum(K)
        values=list(itertools.product((0,F(1,2),1),repeat=3))
        for u,v in itertools.product(values,repeat=2):
            lhs=supnorm(difference(matvec(K,u),matvec(K,v)))
            self.assertLessEqual(lhs,rho*supnorm(difference(u,v)))

    def test_saturation_associative_and_normalization_not(self):
        for x,y,z in itertools.product((0,F(1,4),F(3,4),1),repeat=3):
            self.assertEqual(saturating_add(saturating_add((x,),(y,)),(z,)),
                             saturating_add((x,),saturating_add((y,),(z,))))
        a,b,c=self.e
        self.assertNotEqual(normalized_add(normalized_add(a,b),c),normalized_add(a,normalized_add(b,c)))

    def test_synthetic_pair_irreducible_total_only_error(self):
        results=demo()
        self.assertEqual(results['synthetic_pair_total'],[F(3,2),F(3,2)])
        self.assertEqual(results['synthetic_pair_best_total_only_mse'],F(1,16))
        self.assertEqual(results['synthetic_pair_full_state_mse'],0)

    def test_invalid_inputs_rejected(self):
        with self.assertRaises(ValueError): umbrella((0,1,2),0,-1,1)
        with self.assertRaises(ValueError): add((1,0),(1,))
        with self.assertRaises(ValueError): normalize((0,0))
        with self.assertRaises(ValueError): update(((1,-1),(0,1)),(1,0),(0,0))


if __name__ == '__main__':
    unittest.main()
