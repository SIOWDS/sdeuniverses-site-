from pathlib import Path
import fitz, json, sys
R=Path(__file__).resolve().parent
source=Path(sys.argv[1]); src=fitz.open(source)
OUT=R/'output'
# Preserve selectable text, destinations, and original pagination in both editions.
reading=fitz.open(source)
for i,p in enumerate(reading):
    if i not in [0,len(reading)-1]:
        p.draw_rect(p.rect,color=None,fill=(250/255,248/255,243/255),overlay=False)
reading.set_metadata({**src.metadata,'title':'面对AI的冲击，数学家走向何处？','author':'王德生','subject':'从常规解题到人—AI复合体的多元数学发生 · 数字阅读版v1.0'})
reading.save(OUT/'mathematicians-future-reading.pdf',garbage=4,deflate=True)
printdoc=fitz.open()
W,H=170/25.4*72,240/25.4*72
scales=[]
for i,p in enumerate(src):
    q=printdoc.new_page(width=W,height=H)
    scale=min(W/p.rect.width,H/p.rect.height)
    dx=(W-p.rect.width*scale)/2;dy=(H-p.rect.height*scale)/2
    target=fitz.Rect(dx,dy,dx+p.rect.width*scale,dy+p.rect.height*scale)
    q.show_pdf_page(target,src,i)
    scales.append((scale,dx,dy))
for i,p in enumerate(src):
    s,x,y=scales[i]
    for link in p.get_links():
        data={k:v for k,v in link.items() if k not in ['xref','id']}
        box=link['from'];data['from']=fitz.Rect(box.x0*s+x,box.y0*s+y,box.x1*s+x,box.y1*s+y)
        if link['kind']==fitz.LINK_GOTO and link.get('page',-1)>=0:
            ds,dx,dy=scales[link['page']]
            point=link.get('to',fitz.Point(0,0));data['to']=fitz.Point(point.x*ds+dx,point.y*ds+dy)
        try:printdoc[i].insert_link(data)
        except ValueError:pass
printdoc.set_toc(src.get_toc())
printdoc.set_metadata({**src.metadata,'title':'面对AI的冲击，数学家走向何处？','author':'王德生','subject':'从常规解题到人—AI复合体的多元数学发生 · 印刷版v1.0'})
printdoc.save(OUT/'mathematicians-future-print.pdf',garbage=4,deflate=True)
# Final book front and back for the web. These are typeset page renderings.
reading[0].get_pixmap(matrix=fitz.Matrix(2.5,2.5)).save(R/'figures'/'cover.png')
reading[-1].get_pixmap(matrix=fitz.Matrix(2.5,2.5)).save(R/'figures'/'backcover.png')
result={'pages':len(src),'reading_mm':[190,250],'print_mm':[170,240],'outline_entries':len(src.get_toc()),'links_reading':sum(len(p.get_links()) for p in reading),'links_print':sum(len(p.get_links()) for p in printdoc)}
(R/'qa'/'pdf_editions.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False))
