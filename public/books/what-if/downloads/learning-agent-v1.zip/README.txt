《What If？》学习与智能体包 v1.0
双击 learning.html 可离线阅读任务与导出笔记。原文链接、智能问对及模型服务需要联网；智能体代码供部署或研究，不宣称双击离线即可运行AI。
在线学习：https://sdeuniverses.com/books/what-if/learning.html
在线问对：https://sdeuniverses.com/books/what-if/agent/
学习任务是配套设计，AI不是作者本人。
